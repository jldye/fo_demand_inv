import { takeLatest, call, select } from 'redux-saga/effects';
import { UPLOAD_FILE } from '../actions';
import { uploadInputFile, getFileStatus } from '../data-service';
import { userDetailsSelector } from '../selectors';

function* uploadFileFn({ file, selectedOption }) {
  try {
    const userDetails = yield select(userDetailsSelector);
    const { data } = yield call(getFileStatus, userDetails.token);

    const inventory_file_status = data['inventory_excel_file_status'];
    const demand_file_status = data['demand_forecast_excel_file_status'];

    if (
      (inventory_file_status === 'FileProcessFinish' &&
        demand_file_status === 'NA') ||
      (inventory_file_status === 'NA' &&
        demand_file_status === 'FileProcessFinish') ||
      (inventory_file_status === 'FileProcessFinish' &&
        demand_file_status === 'FileProcessFinish')
    ) {
      yield call(uploadInputFile, file, selectedOption, userDetails.token);
    } else {
      alert(
        'File Uploading already in process. Please try again after some time'
      );
    }
  } catch (error) {
    console.error(error);
  }
}

export function* uploadFileSaga() {
  yield takeLatest(UPLOAD_FILE, uploadFileFn);
}
