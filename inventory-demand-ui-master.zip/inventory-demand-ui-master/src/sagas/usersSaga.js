import {takeLatest, put, call, select} from 'redux-saga/effects';
import {userDetailsSelector} from '../selectors';

import {
    ADD_USER,
    DELETE_USER,
    GET_USER_LIST, getUserList, setUserList, setUserRoleList, UPDATE_USER,
} from '../actions';

import {
    getUserDataTable,
    getUserRoleDataTable,
    updateUserEntries,
    deleteUserEntries,
    createUserEntries
} from '../data-service';

function* getUserListFn() {
    const userDetails = yield select(userDetailsSelector);
    const userList = yield call(getUserDataTable, userDetails.token);
    yield put(setUserList(userList.data.data));
    const userRoleList = yield call(getUserRoleDataTable, userDetails.token);
    yield put(setUserRoleList(userRoleList.data.data));

}

function* deleteUserFn({user}) {
    const userDetails = yield select(userDetailsSelector);
    yield call(deleteUserEntries, user, userDetails.token);
    yield put(getUserList());
}

function* updateUserFn({user}) {
    const userDetails = yield select(userDetailsSelector);
    yield call(updateUserEntries, user, userDetails.token);
    yield put(getUserList());
}

function* addUserFn({user}) {
    const userDetails = yield select(userDetailsSelector);
    yield call(createUserEntries, user, userDetails.token);
    yield put(getUserList());
}

export function* usersSaga() {
    yield takeLatest(GET_USER_LIST, getUserListFn);
}

export function* deleteUserSaga() {
    yield takeLatest(DELETE_USER, deleteUserFn);
}

export function* updateUserSaga() {
    yield takeLatest(UPDATE_USER, updateUserFn);
}

export function* addUserSaga() {
    yield takeLatest(ADD_USER, addUserFn);
}
