import { takeLatest, put, call, select } from 'redux-saga/effects';
import { userDetailsSelector } from '../selectors';

import {
  GET_INVENTORY_RAW_DATA,
  setCurrentBuyersInventoryDashboard,
  setCurrentEnginesInventoryDashboard,
  setInventoryRawData,
  setLoadingInventoryRawData,
} from '../actions';

import { getInventoryRawData } from '../data-service';
import { buyersSelector, enginesSelector } from '../selectors';

function* getInventoryRawDataFn({ fileName }) {
  const userDetails = yield select(userDetailsSelector);
  yield put(setLoadingInventoryRawData(true));
  const { data } = yield call(getInventoryRawData, fileName, userDetails.token);
  yield put(setInventoryRawData(data.data));
  yield put(setLoadingInventoryRawData(false));
  yield put(setCurrentEnginesInventoryDashboard(yield select(enginesSelector)));
  yield put(setCurrentBuyersInventoryDashboard(yield select(buyersSelector)));
}

export function* inventoryRawDataSaga() {
  yield takeLatest(GET_INVENTORY_RAW_DATA, getInventoryRawDataFn);
}
