import { takeEvery, put, call, select } from 'redux-saga/effects';
import { userDetailsSelector } from '../selectors';

import {
  GET_DEMAND_RAW_DATA,
  setCurrentPartsDemandDashboard,
  setCurrentCustomersDemandDashboard,
  setDemandRawData,
  setLoadingDemandRawData,
} from '../actions';

import { getDemandForecastData } from '../data-service';
import { partsSelector, customersSelector } from '../selectors';

function* getDemandRawDataFn({ fileName, tabName }) {
  yield put(setLoadingDemandRawData(true));
  const userDetails = yield select(userDetailsSelector);
  const { data } = yield call(
    getDemandForecastData,
    fileName,
    tabName,
    userDetails.token
  );
  yield put(setDemandRawData(data.data, tabName));
  yield put(setLoadingDemandRawData(false));
  yield put(
    setCurrentCustomersDemandDashboard(yield select(customersSelector))
  );
  yield put(setCurrentPartsDemandDashboard(yield select(partsSelector)));
}

export function* demandRawDataSaga() {
  yield takeEvery(GET_DEMAND_RAW_DATA, getDemandRawDataFn);
}
