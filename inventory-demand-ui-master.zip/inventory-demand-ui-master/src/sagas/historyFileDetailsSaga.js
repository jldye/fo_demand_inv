import { takeEvery, put, call, select } from 'redux-saga/effects';
import { userDetailsSelector } from '../selectors';

import {
    GET_HISTORY_FILE_DETAILS,
    setHistoryFileDetails,
} from '../actions';

import {getHistoryFileDetails} from '../data-service';

function* getHistoryFileDetailsFn() {
    const userDetails = yield select(userDetailsSelector);
    const { data } = yield call(
        getHistoryFileDetails,
        userDetails.clientid,
        userDetails.username,
        userDetails.token
    );
    yield put(setHistoryFileDetails(data.data));
}

export function* historyFileDetailsSaga() {
    yield takeEvery(GET_HISTORY_FILE_DETAILS, getHistoryFileDetailsFn);
}
