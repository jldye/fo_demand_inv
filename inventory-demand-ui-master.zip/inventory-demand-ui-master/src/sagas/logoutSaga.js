import { takeLatest, put } from 'redux-saga/effects';
import { LOGOUT, setUserDetails } from '../actions';

function* logoutFn({ history }) {
  try {
    yield history.push('/login');
    yield put(setUserDetails({}));
  } catch (error) {
    console.error(error);
  }
}

export function* logoutSaga() {
  yield takeLatest(LOGOUT, logoutFn);
}
