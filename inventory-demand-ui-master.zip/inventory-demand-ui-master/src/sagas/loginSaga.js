import {takeLatest, put, call} from 'redux-saga/effects';
import {
    LOGIN,
    setUserDetails,
    setCurrentInventoryFile,
    setLoginComplete,
    getInventoryRawData,
    getDemandRawData,
    getHistoryFileDetails,
    getUserList,
    getCompanyList,
} from '../actions';
import {loginWithCredentials} from '../data-service';
import _ from 'lodash';

function* loginWithCredentialsFn({client, user, password, history, from}) {
    try {
        yield put(setLoginComplete(false));
        const {data} = yield call(loginWithCredentials, client, user, password);
        const userDetails = {};
        if (data.message === 'NoUserFoundError') {
            alert(
                'The Client, Username and Password combination does not match with any existing user'
            );
        }

        if (
            data.message === 'UserSuccessLogin' &&
            data['customerstatus'] === true
        ) {
            userDetails['companyname'] = data['clientname'];
            userDetails['username'] = data['username'];
            userDetails['token'] = data['token'];
            userDetails['role'] = data['userrole'];
            userDetails['clientid'] = data['clientid'];
            userDetails['userrole'] = data['userrole'];
            yield put(setUserDetails(userDetails));
        }

        if (_.includes(['admin', 'user'], data['userrole'])) {
            yield put(setCurrentInventoryFile(data['filestatus']['input_file_name']));
            yield put(getInventoryRawData(''));
            yield put(getDemandRawData('', 'Predictions - 24 Months'));
            yield put(getDemandRawData('', 'Forecast Vs Actual - 12 Months'));
            yield put(getDemandRawData('', '(5) Model Summary'));
            yield put(getDemandRawData('', 'History Raw Data'));
            yield put(getDemandRawData('', '(6) Historical Exception Report'));
            yield put(getDemandRawData('', '(7) Forecastable- Unmeasureable'));
            yield put(getDemandRawData('', '(8) Un-Forecastable Listing'));
            yield put(getHistoryFileDetails());
            history.replace(from);
        }

        if (data['userrole'] === 'admin') {
            yield put(getUserList());
        }

        if (data['userrole'] === 'superadmin') {
            yield put(getCompanyList());
            history.push('/onboarding')
        }
        yield put(setLoginComplete(true));
    } catch (error) {
        console.error(error);
    }
}

export function* loginSaga() {
    yield takeLatest(LOGIN, loginWithCredentialsFn);
}
