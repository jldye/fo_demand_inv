import {takeLatest, put, call, select} from 'redux-saga/effects';
import {userDetailsSelector} from '../selectors';

import {
    ADD_COMPANY,
    DELETE_COMPANY,
    GET_COMPANY_LIST, getCompanyList, setCompanyList, UPDATE_COMPANY,
} from '../actions';

import {
    getCompanyDetails,
    createCompany,
    updateCompany,
    deleteCompany
} from '../data-service';

function* getCompaniesListFn() {
    const userDetails = yield select(userDetailsSelector);
    const companyList = yield call(getCompanyDetails, userDetails.token);
    yield put(setCompanyList(companyList.data.data));
}

function* deleteCompanyFn({company}) {
    const userDetails = yield select(userDetailsSelector);
    yield call(deleteCompany, company, userDetails.token);
    yield put(getCompanyList());
}

function* updateCompanyFn({company}) {
    const userDetails = yield select(userDetailsSelector);
    yield call(updateCompany, company, userDetails.token);
    yield put(getCompanyList());
}

function* addCompanyFn({company}) {
    const userDetails = yield select(userDetailsSelector);
    yield call(createCompany, company, userDetails.token);
    yield put(getCompanyList());
}

export function* companySaga() {
    yield takeLatest(GET_COMPANY_LIST, getCompaniesListFn);
}

export function* deleteCompanySaga() {
    yield takeLatest(DELETE_COMPANY, deleteCompanyFn);
}

export function* updateCompanySaga() {
    yield takeLatest(UPDATE_COMPANY, updateCompanyFn);
}

export function* addCompanySaga() {
    yield takeLatest(ADD_COMPANY, addCompanyFn);
}
