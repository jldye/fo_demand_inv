// src/ui/theme/index.js

import {createMuiTheme} from '@material-ui/core/styles';

const palette = {
    primary: {main: '#56D9FD'},
    secondary: {main: '#7C4DFF'}
};
const themeName = 'Malibu Electric Violet Mouse';

export const theme = createMuiTheme({palette, themeName});
