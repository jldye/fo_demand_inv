import {createMuiTheme} from '@material-ui/core/styles';

const palette = {
    primary: {main: '#6f6fba'},
    secondary: {main: '#164087'}
};
const themeName = 'Ship Cove Chathams Blue Duck';

export const theme = createMuiTheme({palette, themeName});
