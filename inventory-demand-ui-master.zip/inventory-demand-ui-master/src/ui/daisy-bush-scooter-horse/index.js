import {createMuiTheme} from '@material-ui/core/styles';

const palette = {
    primary: {main: '#512DA8'},
    secondary: {main: '#26C6DA'}
};
const themeName = 'Daisy Bush Scooter Horse';

export const theme = createMuiTheme({palette, themeName});
