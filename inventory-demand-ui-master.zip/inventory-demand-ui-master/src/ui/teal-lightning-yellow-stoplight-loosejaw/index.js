// src/ui/theme/index.js

import {createMuiTheme} from '@material-ui/core/styles';

const palette = {
    primary: {main: '#00897B'},
    secondary: {main: '#FBC02D'}
};
const themeName = 'Teal Lightning Yellow Stoplight Loosejaw';

export const theme = createMuiTheme({palette, themeName});
