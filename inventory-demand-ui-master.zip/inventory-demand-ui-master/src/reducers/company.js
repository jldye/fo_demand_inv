import {createReducer} from "../utility";
import {SET_COMPANY_LIST} from "../actions";

export const companyList = createReducer(null, {
    [SET_COMPANY_LIST](state, {companyList}) {
        return companyList;
    }
});
