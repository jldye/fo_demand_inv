import {createReducer} from '../utility';
import {
    SET_CURRENT_PARTS_DEMAND_DASHBOARD,
    SET_CURRENT_CUSTOMERS_DEMAND_DASHBOARD,
    SET_CURRENT_OPTION_DEMAND_DASHBOARD,
    SET_DEMAND_DATA_RADIO_OPTION,
    SET_DEMAND_DATA_TOGGLE_OPTION,
    SET_DEMAND_RAW_DATA,
    SET_LOADING_DEMAND_RAW_DATA,
} from '../actions';

export const demandRawData = createReducer(null, {
    [SET_DEMAND_RAW_DATA](state, {demandRawData, tabName}) {
        return {
            ...state,
            [tabName]: demandRawData,
        };
    }
});

export const demandDataRadioOption = createReducer(null, {
    [SET_DEMAND_DATA_RADIO_OPTION](state, {demandDataRadioOption}) {
        return demandDataRadioOption;
    }
});

export const demandDataToggleOption = createReducer(null, {
    [SET_DEMAND_DATA_TOGGLE_OPTION](state, {demandDataToggleOption}) {
        return demandDataToggleOption;
    }
});
export const currentPartsDemandDashboard = createReducer([], {
    [SET_CURRENT_PARTS_DEMAND_DASHBOARD](state, {currentPartsDemandDashboard}) {
        return currentPartsDemandDashboard;
    }
});
export const currentCustomersDemandDashboard = createReducer([], {
    [SET_CURRENT_CUSTOMERS_DEMAND_DASHBOARD](state, {currentCustomersDemandDashboard}) {
        return currentCustomersDemandDashboard;
    }
});
export const currentOptionDemandDashboard = createReducer(null, {
    [SET_CURRENT_OPTION_DEMAND_DASHBOARD](state, {currentOptionDemandDashboard}) {
        return currentOptionDemandDashboard;
    }
});
export const loadingDemandRawData = createReducer(null, {
    [SET_LOADING_DEMAND_RAW_DATA](state, {loadingDemandRawData}) {
        return loadingDemandRawData;
    },
});
