import {createReducer} from '../utility';
import {
    APPEND_INVENTORY_RAW_DATA,
    SET_CURRENT_BUYERS_INVENTORY_DASHBOARD,
    SET_CURRENT_ENGINES_INVENTORY_DASHBOARD,
    SET_CURRENT_OPTION_INVENTORY_DASHBOARD,
    SET_INVENTORY_DATA_RADIO_OPTION,
    SET_INVENTORY_DATA_TOGGLE_OPTION,
    SET_INVENTORY_RAW_DATA,
    SET_LOADING_INVENTORY_RAW_DATA
} from '../actions'

export const inventoryRawData = createReducer(null, {
    [SET_INVENTORY_RAW_DATA](state, {inventoryRawData}) {
        return inventoryRawData;
    },
    [APPEND_INVENTORY_RAW_DATA](state, {inventoryRawData}) {
        return [...state.inventoryRawData, ...inventoryRawData];
    }
});

export const inventoryDataRadioOption = createReducer(null, {
    [SET_INVENTORY_DATA_RADIO_OPTION](state, {inventoryDataRadioOption}) {
        return inventoryDataRadioOption;
    }
});

export const inventoryDataToggleOption = createReducer(null, {
    [SET_INVENTORY_DATA_TOGGLE_OPTION](state, {inventoryDataToggleOption}) {
        return inventoryDataToggleOption;
    }
});
export const currentBuyersInventoryDashboard = createReducer([], {
    [SET_CURRENT_BUYERS_INVENTORY_DASHBOARD](state, {currentBuyersInventoryDashboard}) {
        return currentBuyersInventoryDashboard;
    }
});
export const currentEnginesInventoryDashboard = createReducer([], {
    [SET_CURRENT_ENGINES_INVENTORY_DASHBOARD](state, {currentEnginesInventoryDashboard}) {
        return currentEnginesInventoryDashboard;
    }
});
export const currentOptionInventoryDashboard = createReducer(null, {
    [SET_CURRENT_OPTION_INVENTORY_DASHBOARD](state, {currentOptionInventoryDashboard}) {
        return currentOptionInventoryDashboard;
    }
});
export const loadingInventoryRawData = createReducer(null, {
    [SET_LOADING_INVENTORY_RAW_DATA](state, {loadingInventoryRawData}) {
        return loadingInventoryRawData;
    }
});
