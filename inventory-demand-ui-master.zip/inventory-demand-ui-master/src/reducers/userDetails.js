import { createReducer } from '../utility';
import {
  SET_CURRENT_INVENTORY_FILE,
  SET_CURRENT_TAB,
  SET_HISTORY_FILE_DETAILS,
  SET_LOGIN_COMPLETE,
  SET_USER_DATA,
  SET_CURRENT_DEMAND_FILE, SET_USER_LIST, SET_USER_ROLE_LIST,
} from '../actions';

export const userDetails = createReducer(null, {
  [SET_USER_DATA](state, { userDetails }) {
    return userDetails;
  }
});
export const loginComplete = createReducer(null, {
  [SET_LOGIN_COMPLETE](state, { loginComplete }) {
    return loginComplete;
  },
});
export const currentInventoryFile = createReducer(null, {
  [SET_CURRENT_INVENTORY_FILE](state, { currentInventoryFile }) {
    return currentInventoryFile;
  }
});

export const currentDemandFile = createReducer(null, {
  [SET_CURRENT_DEMAND_FILE](state, { currentDemandFile }) {
    return currentDemandFile;
  }
});

export const currentTab = createReducer(null, {
  [SET_CURRENT_TAB](state, { currentTab }) {
    return currentTab;
  }
});

export const historyFileDetails = createReducer(null, {
  [SET_HISTORY_FILE_DETAILS](state, { historyFileDetails }) {
    return historyFileDetails;
  }
});

export const userList = createReducer(null, {
  [SET_USER_LIST](state, { userList }) {
    return userList;
  }
});

export const userRoleList = createReducer(null, {
  [SET_USER_ROLE_LIST](state, { userRoleList }) {
    return userRoleList;
  }
});
