import {createSelector} from 'reselect';
import {checkForValid, meanOfNaRM, sumOfNaRM} from '../utility';
import numeral from 'numeral';
import _ from 'lodash';

const columnnameConfig = {
    Final_Rank: 'Zone',
    Part_Number: 'Smart Part',
    Buyer: 'Buyer',
    Uf_ASI_Item_Engine: 'Uf ASI Item Engine',
    Quantity_36months: 'Quantity (Past 36 Months)',
    Avg_Monthly_COGs: 'Average COGs (Past 12 Months)',
    Quantity_Cost: 'Total COGs',
    Hist_Avg_Monthly_Inventory_Quantity:
        'Average Monthly Ending Inventory (Quantity)',
    Hist_Average_monthly_Inventory_Value:
        'Average Monthly Ending Inventory (COGs)',
    OH_Inventory: 'On Hand Inventory (Quantity)',
    OH_Inventory_Value: 'On Hand Inventory (COGs)',
    Hist_Safety_Stock_Quantity: 'Estimated Historical Safety Stock (Quantity)',
    Hist_Safety_Stock_Value: 'Estimated Historical Safety Stock (COGs)',
    Hist_Cycle_Stock_Quantity: 'Estimated Historical Cycle Stock (Quantity)',
    Hist_Cycle_Stock_Value: 'Estimated Historical Cycle Stock (COGs)',
    Weighted_Historic_Service_Level_Num: 'Weighted Service Level Numerator',
    Target_Cycle_Stock_Quantity: 'Target Cycle Stock (Quantity)',
    Target_Cycle_Stock_Value: 'Target Cycle Stock (COGs)',
    Target_Safety_Stock_Quantity: 'Target Safety Stock (Quantity)',
    Target_Safety_Stock_Value: 'Target Safety Stock (COGs)',
    Target_Average_Monthly_Inventory_Quantity:
        'Target Average Monthly Inventory (Quantity)',
    Target_Average_Monthly_Inventory_Value:
        'Target Average Monthly Inventory (COGs)',
    Target_Service_Level: 'Target Service Level',
    Run_Date: 'Run Date',
};

export const inventoryRawDataSelector = (state) =>
    state.get('inventoryRawData');
export const currentOptionInventoryDashboardSelector = (state) =>
    state.get('currentOptionInventoryDashboard');
export const currentBuyersInventoryDashboardSelector = (state) =>
    state.get('currentBuyersInventoryDashboard');
export const currentEnginesInventoryDashboardSelector = (state) =>
    state.get('currentEnginesInventoryDashboard');

export const inventoryDataRadioOptionSelector = (state) =>
    state.get('inventoryDataRadioOption');
export const inventoryDataToggleOptionSelector = (state) =>
    state.get('inventoryDataToggleOption');

const mapDetails = (rec, id, label) => {
    let output = {
        'Service Level':
            100 *
            checkForValid(
                sumOfNaRM(rec, columnnameConfig.Weighted_Historic_Service_Level_Num) /
                sumOfNaRM(rec, columnnameConfig.Quantity_Cost)
            ),
        'Turns per Year':
            checkForValid(12 * sumOfNaRM(rec, columnnameConfig.Avg_Monthly_COGs)) /
            sumOfNaRM(rec, columnnameConfig.Hist_Average_monthly_Inventory_Value),
        'Cycle Stock': sumOfNaRM(rec, columnnameConfig.Hist_Cycle_Stock_Value),
        'Safety Stock': sumOfNaRM(rec, columnnameConfig.Hist_Safety_Stock_Value),
        Inventory: sumOfNaRM(
            rec,
            columnnameConfig.Hist_Average_monthly_Inventory_Value
        ),
        'Overage Inventory': numeral(
            sumOfNaRM(rec, columnnameConfig.Hist_Average_monthly_Inventory_Value) -
            (sumOfNaRM(rec, columnnameConfig.Hist_Cycle_Stock_Value) +
                sumOfNaRM(rec, columnnameConfig.Hist_Safety_Stock_Value))
        ).format('0.00'),
        'On Hand Inventory': sumOfNaRM(rec, columnnameConfig.OH_Inventory_Value),
        'Target Service Level':
            100 *
            checkForValid(meanOfNaRM(rec, columnnameConfig.Target_Service_Level)),
        'Target Turns per Year':
            (12 * sumOfNaRM(rec, columnnameConfig.Avg_Monthly_COGs)) /
            sumOfNaRM(rec, columnnameConfig.Target_Average_Monthly_Inventory_Value),
        'Target Cycle Stock': sumOfNaRM(
            rec,
            columnnameConfig.Target_Cycle_Stock_Value
        ),
        'Target Safety Stock': sumOfNaRM(
            rec,
            columnnameConfig.Target_Safety_Stock_Value
        ),
        'Target Inventory': sumOfNaRM(
            rec,
            columnnameConfig.Target_Average_Monthly_Inventory_Value
        ),
    };
    output[label] = id;
    return output;
};

const exceptionReportMap = (data) => ({
    Zone: data[columnnameConfig.Final_Rank],
    'Run Date': data[columnnameConfig.Run_Date],
    'Smart Part': data[columnnameConfig.Part_Number],
    'Average COGs (Monthly)': data[columnnameConfig.Avg_Monthly_COGs],
    'Actual Safety Stock': data[columnnameConfig.Hist_Safety_Stock_Value],
    'Target Safety Stock': data[columnnameConfig.Target_Safety_Stock_Value],
    'Actual to Target':
        1 -
        Math.abs(
            parseFloat(data[columnnameConfig.Target_Safety_Stock_Value]) -
            (_.isEmpty(data[columnnameConfig.Hist_Safety_Stock_Value])
                ? 0
                : parseFloat(data[columnnameConfig.Hist_Safety_Stock_Value]))
        ) /
        (parseFloat(data[columnnameConfig.Target_Safety_Stock_Value]) >
        (_.isEmpty(data[columnnameConfig.Hist_Safety_Stock_Value])
            ? 0
            : parseFloat(data[columnnameConfig.Hist_Safety_Stock_Value]))
            ? parseFloat(data[columnnameConfig.Target_Safety_Stock_Value])
            : _.isEmpty(data[columnnameConfig.Hist_Safety_Stock_Value])
                ? 0
                : parseFloat(data[columnnameConfig.Hist_Safety_Stock_Value])),
});

export const groupByZoneSelector = createSelector(
    [
        inventoryRawDataSelector,
        currentBuyersInventoryDashboardSelector,
        currentEnginesInventoryDashboardSelector,
    ],
    (inventoryRawData, buyers, engines) => {
        try {
            return _(inventoryRawData)
                .filter((x) => _.includes(buyers, x['Buyer']))
                .filter((y) => _.includes(engines, y['Uf ASI Item Engine']))
                .groupBy('Zone')
                .map((rec, id) => mapDetails(rec, id, 'Zone'))
                .sortBy((z) => z['Zone'])
                .value();
        } catch (e) {
            return [];
        }
    }
);

export const groupByPartSelector = createSelector(
    [
        inventoryRawDataSelector,
        currentBuyersInventoryDashboardSelector,
        currentEnginesInventoryDashboardSelector,
    ],
    (inventoryRawData, buyers, engines) => {
        try {
            return _(inventoryRawData)
                .filter((x) => _.includes(buyers, x['Buyer']))
                .filter((y) => _.includes(engines, y['Uf ASI Item Engine']))
                .groupBy('Smart Part')
                .map((rec, id) => mapDetails(rec, id, 'Smart Part'))
                .sortBy((z) => z['Smart Part'])
                .value();
        } catch (e) {
            return [];
        }
    }
);

export const inventoryExceptionReportSelector = createSelector(
    [
        inventoryRawDataSelector,
        currentBuyersInventoryDashboardSelector,
        currentEnginesInventoryDashboardSelector,
    ],
    (inventoryRawData, buyers, engines) => {
        try {
            return _(inventoryRawData)
                .filter((x) => _.includes(buyers, x['Buyer']))
                .filter((y) => _.includes(engines, y['Uf ASI Item Engine']))
                .filter((y) => y['Actual to Target'] >= 0.5)
                .map(exceptionReportMap)
                .value();
        } catch (e) {
            return [];
        }
    }
);

export const currentDashboardDataSelector = createSelector(
    [groupByZoneSelector, currentOptionInventoryDashboardSelector],
    (x, y) =>
        x.map((entry) => ({
            Zone: entry['Zone'],
            Target: entry[`Target ${y}`],
            Estimate: entry[y],
        }))
);

export const serviceLevelSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        numeral(
            100 *
            checkForValid(
                sumOfNaRM(
                    inventoryRawData,
                    columnnameConfig.Weighted_Historic_Service_Level_Num
                ) / sumOfNaRM(inventoryRawData, columnnameConfig.Quantity_Cost)
            )
        ).format('0.00')
);

export const turnsPerYearSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        numeral(
            checkForValid(
                12 * sumOfNaRM(inventoryRawData, columnnameConfig.Avg_Monthly_COGs)
            ) /
            sumOfNaRM(
                inventoryRawData,
                columnnameConfig.Hist_Average_monthly_Inventory_Value
            )
        ).format('0.00')
);

export const cycleStockPerMonthSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        numeral(
            sumOfNaRM(inventoryRawData, columnnameConfig.Hist_Cycle_Stock_Value)
        ).format('0.0a')
);

export const safetyStockPerMonthSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        numeral(
            sumOfNaRM(inventoryRawData, columnnameConfig.Hist_Safety_Stock_Value)
        ).format('0.0a')
);

export const overageInventoryPerMonthSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        numeral(
            sumOfNaRM(
                inventoryRawData,
                columnnameConfig.Hist_Average_monthly_Inventory_Value
            ) -
            (sumOfNaRM(inventoryRawData, columnnameConfig.Hist_Cycle_Stock_Value) +
                sumOfNaRM(inventoryRawData, columnnameConfig.Hist_Safety_Stock_Value))
        ).format('0.0a')
);

export const averageInventoryPerMonthSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        numeral(
            sumOfNaRM(
                inventoryRawData,
                columnnameConfig.Hist_Average_monthly_Inventory_Value
            )
        ).format('0.0a')
);

export const onHandInventorySelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        sumOfNaRM(inventoryRawData, columnnameConfig.OH_Inventory_Value)
);

export const targetServiceLevelSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        checkForValid(
            meanOfNaRM(inventoryRawData, columnnameConfig.Target_Service_Level)
        )
);

export const targetTurnsPerYearSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        (12 * sumOfNaRM(inventoryRawData, columnnameConfig.Avg_Monthly_COGs)) /
        sumOfNaRM(
            inventoryRawData,
            columnnameConfig.Target_Average_Monthly_Inventory_Value
        )
);

export const targetCycleStockPerMonthSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        sumOfNaRM(inventoryRawData, columnnameConfig.Target_Cycle_Stock_Value)
);

export const targetSafetyStockPerMonthSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        sumOfNaRM(inventoryRawData, columnnameConfig.Target_Safety_Stock_Value)
);

export const targetInventoryPerMonthSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) =>
        sumOfNaRM(
            inventoryRawData,
            columnnameConfig.Target_Average_Monthly_Inventory_Value
        )
);
