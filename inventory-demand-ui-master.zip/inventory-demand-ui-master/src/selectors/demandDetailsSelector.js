import { createSelector } from 'reselect';
import _ from 'lodash';
import moment from 'moment';
import {
  changeDateFormat,
  distinctItem,
  meanOfNaRM,
  roundOfNaRM,
  sumOfNaRM,
} from '../utility';

const FAcolumnnameConfig = {
  Part_Number: 'Part_Number',
  Customer: 'Customer',
  Gross_Margin: 'Gross_Margin',
  Forecast: 'Forecast',
  Quantity: 'Quantity',
  Running_Delta_3: 'Running_Delta_3',
  Running_Delta_6: 'Running_Delta_6',
  Running_Max_6: 'Running_Max_6',
  Running_Max_3: 'Running_Max_3',
  Measurement_Period: 'Measurement_Period',
  Date: 'Date',
};

const HRColumnConfig = {
  Received_Date: 'Received_Date',
  Part_Number: 'Part_Number',
  Customer: 'Customer',
  Quantity: 'Quantity',
  Gross_Margin: 'Gross_Margin',
};

const HERColumnConfig = {
  Part_Number: 'Part Number',
  Customer: 'Customer',
  Quantity: 'Quantity',
  Received_Date: 'Received Date',
  Gross_Margin: 'Gross Margin',
  Alert: 'Alert',
  Lower_Bound: 'Lower Bound',
  Upper_Bound: 'Upper Bound',
};

const UFLColumnConfig = {
  Part_Number: 'Part Number',
  Customer: 'Customer',
  Gross_Margin: 'Gross Margin (Total)',
};

const FUColumnConfig = {
  Part_Number: 'Part Number',
  Customer: 'Customer',
  Gross_Margin: 'Gross Margin (12 Months)',
};

const MSColumnConfig = {
  Part_Number: 'Part Number',
  Customer: 'Customer',
  Tweleve_Month_Accuracy_Group: '12 Month Accuracy Group',
  Gross_Margin: 'Gross Margin (12 Months)',
  Total_Forecast_Quantity: 'Total Forecast Quantity (12 Months)',
  Total_Quantity: 'Total Quantity (12 Months)',
  Forecast_Accuracy_12_Months: 'Forecast Accuracy (12 Months)',
  Forecast_Accuracy_Running_6_Months: 'Forecast Accuracy (Running 6 Months)',
  Forecast_Accuracy_Running_3_Months: 'Forecast Accuracy (Running 3 Months)',
  Mean_Average_Error: 'Mean Average Error',
  Selected_Model: 'Selected Model',
  Rolling_3_Month_Accuracy_Group: 'Rolling 3 Month Accuracy Group',
  Rolling_6_Month_Accuracy_Group: 'Rolling 6 Month Accuracy Group',
};

const demandOptionLabel = {
  'Full Period': '12 Month Accuracy Group',
  '6 Months': 'Rolling 6 Month Accuracy Group',
  '3 Months': 'Rolling 3 Month Accuracy Group',
};

const pivotMonthAndYear = (value, key, label) => {
  const labels = label.split('#');
  const initial = _.reduce(
    labels,
    (acc, rec) => ({ ...acc, [rec]: value[0][rec] }),
    { 'Grand Total': 0 }
  );

  return _.reduce(
    value,
    (acc, rec) => {
      const monthAndYear = rec['monthAndYear'];
      const year = rec['year'];
      let interim = {};
      const forecast = Number(rec['Forecast']);

      if (!acc[monthAndYear]) {
        interim = {
          ...acc,
          [monthAndYear]: forecast,
        };
      } else {
        interim = {
          ...acc,
          [monthAndYear]: Number(acc[monthAndYear]) + forecast,
        };
      }

      if (!acc[`Total ${year}`]) {
        interim[`Total ${year}`] = forecast;
      } else {
        interim[`Total ${year}`] = Number(acc[`Total ${year}`]) + forecast;
      }

      interim['Grand Total'] = Number(acc['Grand Total']) + forecast;

      return interim;
    },
    initial
  );
};

const demandBarChartMapping = (rec, k, option) => {
  const grossMargin = sumOfNaRM(rec, MSColumnConfig.Gross_Margin);
  return {
    'Gross Margin': (grossMargin / 1000000).toFixed(2),
    Label: rec[0][option],
  };
};

const forecastAccuracyMapping = (rec) => {
  let result = {
    Part: rec[0][FAcolumnnameConfig.Part_Number],
    Customer: rec[0][FAcolumnnameConfig.Customer],
    Length_of_Measurement_Period_Months: distinctItem(
      rec,
      FAcolumnnameConfig.Date
    ).length,
    Gross_Margin_Full_Period:
      sumOfNaRM(rec, FAcolumnnameConfig.Gross_Margin)
    ,
    Forecast_Quantity_FullPeriod: roundOfNaRM(
      sumOfNaRM(rec, FAcolumnnameConfig.Forecast)
    ),
    Actual_Quantity_FullPeriod: sumOfNaRM(rec, FAcolumnnameConfig.Quantity),
    Forecast_Accuracy_3_Delta: meanOfNaRM(
      rec,
      FAcolumnnameConfig.Running_Delta_3
    ),
    Forecast_Accuracy_6_Delta: meanOfNaRM(
      rec,
      FAcolumnnameConfig.Running_Delta_6
    ),
    Forecast_Accuracy_3_Max: meanOfNaRM(rec, FAcolumnnameConfig.Running_Max_3),
    Forecast_Accuracy_6_Max: meanOfNaRM(rec, FAcolumnnameConfig.Running_Max_6),
  };

  const fa_full_period = roundOfNaRM(
    (
      (1 -
        Math.abs(
          result['Forecast_Quantity_FullPeriod'] -
            result['Actual_Quantity_FullPeriod']
        ) /
          Math.max(
            result['Forecast_Quantity_FullPeriod'],
            result['Actual_Quantity_FullPeriod']
          )) *
      100
    ).toFixed(2)
  );

  result['fa_full_period'] =
    fa_full_period;

  const fa_6_month = roundOfNaRM(
    (
      (1 -
        Math.abs(
          result['Forecast_Accuracy_6_Delta'] /
            result['Forecast_Accuracy_6_Max']
        )) *
      100
    ).toFixed(2)
  );

  result['fa_6_month'] =
    fa_6_month;

  const fa_3_month = roundOfNaRM(
    (
      (1 -
        Math.abs(
          result['Forecast_Accuracy_3_Delta'] /
            result['Forecast_Accuracy_3_Max']
        )) *
      100
    ).toFixed(2)
  );

  result['fa_3_month'] =
    fa_3_month;

  return result;
};

const monthMapping = (rec) => {
  const month = moment(rec[FAcolumnnameConfig.Date].split('T')[0]).format(
    'MMM'
  );
  const year = moment(rec[FAcolumnnameConfig.Date].split('T')[0]).format(
    'YYYY'
  );
  const { Date, ...remaining } = rec;
  return {
    ...remaining,
    monthAndYear: month + ' ' + year,
    dateInMoment: moment().year(year).month(month).date(1).format('YYYY-MM-DD'),
    year: year,
  };
};

const timelineMapping = (value, key) => ({
  Date: key,
  'Actual Quantity': sumOfNaRM(value, FAcolumnnameConfig.Quantity),
  'Forecast Quantity': sumOfNaRM(value, FAcolumnnameConfig.Forecast),
});

const historyMapping = (rec) => ({
  Part_Number: rec[HRColumnConfig.Part_Number],
  Customer: rec[HRColumnConfig.Customer],
  Received_Date: changeDateFormat(rec[HRColumnConfig.Received_Date]),
  Gross_Margin: (rec[HRColumnConfig.Gross_Margin]),
  Quantity: rec[HRColumnConfig.Quantity],
});

const historyExceptionMapping = (rec) => ({
  Part_Number: rec[HERColumnConfig.Part_Number],
  Customer: rec[HERColumnConfig.Customer],
  Received_Date: changeDateFormat(rec[HERColumnConfig.Received_Date]),
  Gross_Margin: (rec[HERColumnConfig.Gross_Margin]),
  Quantity: rec[HERColumnConfig.Quantity],
  Alert: 'Demand Event Outside of Tolerance',
  Lower_Bound:
    rec[HERColumnConfig.Lower_Bound] < 0
      ? 0
      : parseFloat(rec[HERColumnConfig.Lower_Bound]).toFixed(1),
  Upper_Bound: parseFloat(rec[HERColumnConfig.Upper_Bound]).toFixed(1),
});

const unforecastableDemandMapping = (rec) => ({
  Part_Number: rec[UFLColumnConfig.Part_Number],
  Customer: rec[UFLColumnConfig.Customer],
  Gross_Margin: (rec[UFLColumnConfig.Gross_Margin]),
});

const forecastableDemandMapping = (rec) => ({
  Part_Number: rec[FUColumnConfig.Part_Number],
  Customer: rec[FUColumnConfig.Customer],
  Gross_Margin: (rec[FUColumnConfig.Gross_Margin]),
});

const modelDetailsMapping = (rec) => {
  let result = {
    Part: rec[MSColumnConfig.Part_Number],
    Customer: rec[MSColumnConfig.Customer],
    Selected_Model:
      rec[MSColumnConfig.Tweleve_Month_Accuracy_Group] === 'Un-Forecastable'
        ? 'UnForecastable'
        : rec[MSColumnConfig.Selected_Model],
    Gross_Margin: (rec[MSColumnConfig.Gross_Margin]),
    Actual_Demand_Whole_Period: rec[MSColumnConfig.Total_Quantity],
  };

  const Forecast_Demand_Whole_Period = roundOfNaRM(
    rec[MSColumnConfig.Total_Forecast_Quantity]
  );

  result['Forecast_Demand_Whole_Period'] = Forecast_Demand_Whole_Period.isNaN
    ? ''
    : Forecast_Demand_Whole_Period;

  const Forecast_Accuracy_Whole_Period =
    roundOfNaRM(
      (
        parseFloat(rec[MSColumnConfig.Forecast_Accuracy_12_Months]) * 100
      ).toFixed(2)
    );

  result['Forecast_Accuracy_Whole_Period'] = Forecast_Accuracy_Whole_Period;

  const Forecast_Accuracy_Running_6_Month =
    roundOfNaRM(
      (
        parseFloat(rec[MSColumnConfig.Forecast_Accuracy_Running_6_Months]) * 100
      ).toFixed(2)
    );

  result['Forecast_Accuracy_Running_6_Month'] = Forecast_Accuracy_Running_6_Month;

  const Forecast_Accuracy_Running_3_Month =
    roundOfNaRM(
      (
        parseFloat(rec[MSColumnConfig.Forecast_Accuracy_Running_3_Months]) * 100
      ).toFixed(2)
    );

  result['Forecast_Accuracy_Running_3_Month'] =Forecast_Accuracy_Running_3_Month;

  const Mean_Average_Error_Point_Forecast = parseFloat(
    rec[MSColumnConfig.Mean_Average_Error]
  ).toFixed(2);
  result['Mean_Average_Error_Point_Forecast'] =
    Mean_Average_Error_Point_Forecast === 'NaN'
      ? ''
      : Mean_Average_Error_Point_Forecast;

  return result;
};

export const demandRawDataSelector = (state) => state.get('demandRawData');
export const currentOptionDemandDashboardSelector = (state) =>
  state.get('currentOptionDemandDashboard');
export const currentPartsDemandDashboardSelector = (state) =>
  state.get('currentPartsDemandDashboard');
export const currentCustomersDemandDashboardSelector = (state) =>
  state.get('currentCustomersDemandDashboard');

export const demandDataRadioOptionSelector = (state) =>
  state.get('demandDataRadioOption');
export const demandDataToggleOptionSelector = (state) =>
  state.get('demandDataToggleOption');

export const groupByPartAndCustomerFASelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['Forecast Vs Actual - 12 Months'])
        .filter((x) => _.includes(parts, x[FAcolumnnameConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[FAcolumnnameConfig.Customer]))
        .groupBy(
          (value) =>
            value[FAcolumnnameConfig.Part_Number] +
            '#' +
            value[FAcolumnnameConfig.Customer]
        )
        .map(forecastAccuracyMapping)
        .sortBy((z) => z['Gross_Margin_Full_Period'])
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const groupByPartFASelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['Forecast Vs Actual - 12 Months'])
        .filter((x) => _.includes(parts, x[FAcolumnnameConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[FAcolumnnameConfig.Customer]))
        .groupBy(FAcolumnnameConfig.Part_Number)
        .map(forecastAccuracyMapping)
        .sortBy((z) => z['Gross_Margin_Full_Period'])
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const groupByCustomerFASelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['Forecast Vs Actual - 12 Months'])
        .filter((x) => _.includes(parts, x[FAcolumnnameConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[FAcolumnnameConfig.Customer]))
        .groupBy(FAcolumnnameConfig.Customer)
        .map(forecastAccuracyMapping)
        .sortBy((z) => z['Gross_Margin_Full_Period'])
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const demandForecastAccuracySelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
    currentOptionDemandDashboardSelector,
  ],
  (demandRawData, parts, customers, option) => {
    try {
      const filtered = _(demandRawData['Forecast Vs Actual - 12 Months'])
        .filter((x) => _.includes(parts, x[FAcolumnnameConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[FAcolumnnameConfig.Customer]))
        .value();

      const calculation = {
        Forecast_Quantity_FullPeriod: roundOfNaRM(
          sumOfNaRM(filtered, FAcolumnnameConfig.Forecast)
        ),
        Actual_Quantity_FullPeriod: sumOfNaRM(
          filtered,
          FAcolumnnameConfig.Quantity
        ),
        Forecast_Accuracy_3_Delta: meanOfNaRM(
          filtered,
          FAcolumnnameConfig.Running_Delta_3
        ),
        Forecast_Accuracy_6_Delta: meanOfNaRM(
          filtered,
          FAcolumnnameConfig.Running_Delta_6
        ),
        Forecast_Accuracy_3_Max: meanOfNaRM(
          filtered,
          FAcolumnnameConfig.Running_Max_3
        ),
        Forecast_Accuracy_6_Max: meanOfNaRM(
          filtered,
          FAcolumnnameConfig.Running_Max_6
        ),
      };

      let fa;
      if (option === 'Full Period') {
        fa = (
          1 -
          Math.abs(
            calculation['Forecast_Quantity_FullPeriod'] -
              calculation['Actual_Quantity_FullPeriod']
          ) /
            Math.max(
              calculation['Forecast_Quantity_FullPeriod'],
              calculation['Actual_Quantity_FullPeriod']
            )
        ).toFixed(2);
        fa = isNaN(fa) ? 0 : fa;
        return Math.round(Number(fa) * 100);
      }
      if (option === '6 Months') {
        fa = (
          1 -
          Math.abs(
            calculation['Forecast_Accuracy_6_Delta'] /
              calculation['Forecast_Accuracy_6_Max']
          )
        ).toFixed(2);
        fa = isNaN(fa) ? 0 : fa;
        return Math.round(Number(fa) * 100);
      } else {
        fa = (
          1 -
          Math.abs(
            calculation['Forecast_Accuracy_3_Delta'] /
              calculation['Forecast_Accuracy_3_Max']
          )
        ).toFixed(2);
        fa = isNaN(fa) ? 0 : fa;
        return Math.round(Number(fa) * 100);
      }
    } catch (e) {
      console.error(e);
      return {};
    }
  }
);

export const groupByCustomerPredictionsSelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['Predictions - 24 Months'])
        .filter((x) => _.includes(parts, x[FAcolumnnameConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[FAcolumnnameConfig.Customer]))
        .map(monthMapping)
        .groupBy(FAcolumnnameConfig.Customer)
        .map((v, k) => pivotMonthAndYear(v, k, FAcolumnnameConfig.Customer))
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const groupByPartPredictionsSelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['Predictions - 24 Months'])
        .filter((x) => _.includes(parts, x[FAcolumnnameConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[FAcolumnnameConfig.Customer]))
        .map(monthMapping)
        .groupBy(FAcolumnnameConfig.Part_Number)
        .map((v, k) => pivotMonthAndYear(v, k, FAcolumnnameConfig.Part_Number))
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const groupByPartAndCustomerPredictionsSelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['Predictions - 24 Months'])
        .filter((x) => _.includes(parts, x[FAcolumnnameConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[FAcolumnnameConfig.Customer]))
        .map(monthMapping)
        .groupBy(
          (value) =>
            value[FAcolumnnameConfig.Part_Number] +
            '#' +
            value[FAcolumnnameConfig.Customer]
        )
        .map((v, k) =>
          pivotMonthAndYear(
            v,
            k,
            FAcolumnnameConfig.Part_Number + '#' + FAcolumnnameConfig.Customer
          )
        )
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const demandHistorySelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['History Raw Data'])
        .filter((x) => _.includes(parts, x[HRColumnConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[HRColumnConfig.Customer]))
        .map(historyMapping)
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const demandHistoryExceptionSelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['(6) Historical Exception Report'])
        .filter((x) => _.includes(parts, x[HERColumnConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[HERColumnConfig.Customer]))
        .map(historyExceptionMapping)
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const unforecastableDemandSelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['(8) Un-Forecastable Listing'])
        .filter((x) => _.includes(parts, x[UFLColumnConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[UFLColumnConfig.Customer]))
        .map(unforecastableDemandMapping)
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const forecastableDemandSelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['(7) Forecastable- Unmeasureable'])
        .filter((x) => _.includes(parts, x[FUColumnConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[FUColumnConfig.Customer]))
        .map(forecastableDemandMapping)
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const modelDemandSelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['(5) Model Summary'])
        .filter((x) => _.includes(parts, x[MSColumnConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[MSColumnConfig.Customer]))
        .map(modelDetailsMapping)
        .value();
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const demandBarChartSelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
    currentOptionDemandDashboardSelector,
  ],
  (demandRawData, parts, customers, currentOptionDemandDashboard) => {
    try {
      return _(demandRawData['(5) Model Summary'])
        .filter((x) => _.includes(parts, x[MSColumnConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[MSColumnConfig.Customer]))
        .groupBy(demandOptionLabel[currentOptionDemandDashboard])
        .map((v, k) =>
          demandBarChartMapping(
            v,
            k,
            demandOptionLabel[currentOptionDemandDashboard]
          )
        )
        .reduce(
          (acc, curr) => ({ ...acc, [curr.Label]: curr['Gross Margin'] }),
          {}
        );
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);

export const demandTimelineSelector = createSelector(
  [
    demandRawDataSelector,
    currentPartsDemandDashboardSelector,
    currentCustomersDemandDashboardSelector,
  ],
  (demandRawData, parts, customers) => {
    try {
      return _(demandRawData['Forecast Vs Actual - 12 Months'])
        .filter((x) => _.includes(parts, x[FAcolumnnameConfig.Part_Number]))
        .filter((y) => _.includes(customers, y[FAcolumnnameConfig.Customer]))
        .map(monthMapping)
        .groupBy('dateInMoment')
        .map(timelineMapping)
        .reduce(
          (acc, rec) => {
            let interim = {
              ...acc,
              timelineData: [
                {
                  id: 'Actual',
                  data: [
                    ...acc['timelineData'][0]['data'],
                    { x: rec['Date'], y: rec['Actual Quantity'] },
                  ],
                },
                {
                  id: 'Forecast',
                  data: [
                    ...acc['timelineData'][1]['data'],
                    { x: rec['Date'], y: rec['Forecast Quantity'] },
                  ],
                },
              ],
            };
            return interim;
          },
          {
            timelineData: [
              {
                id: 'Actual',
                data: [],
              },
              {
                id: 'Forecast',
                data: [],
              },
            ],
          }
        );
    } catch (e) {
      console.error(e);
      return [];
    }
  }
);
