import {createSelector} from "reselect";

export const companyListSelector = createSelector(
    state => state.get("companyList"),
    companyList => companyList.map(company => ({
        "Address": company['address'],
        "Company": company['client_name'],
        "Status": company['status'] ? 'Active' : 'Inactive',
        "Email": company['user_emailid'],
        "Admin Username": company['user_name'],
        "Phone Number": company['user_phonenumber']
    }))
)
