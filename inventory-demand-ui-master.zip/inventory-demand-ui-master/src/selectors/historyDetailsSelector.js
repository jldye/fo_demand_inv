import {createSelector} from "reselect";
import _ from "lodash";

export const historyFileDetailsSelector = createSelector(
    state => state.get("historyFileDetails"),
    historyFileDetails => (
        historyFileDetails
            .map(rec => ({
                'Created Date': rec['created_date'],
                'Demand Forecasting': rec['demand_forecast_sheet_output_file_name'],
                'Inventory Analysis': rec['inventory_sheet_output_file_name'],
                'File Name': rec['original_file_name'],
                'Input File Name': rec['input_file_name'],
                'View': 'view'
            }))
            .filter(rec => !(_.isEmpty(rec['Demand Forecasting']) && _.isEmpty(rec['Inventory Analysis'])))
    )
)
