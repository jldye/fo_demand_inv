import {createSelector} from 'reselect'

export const userDetailsSelector = createSelector(
    state => state.get("userDetails"),
    userDetails => userDetails
)

export const userListSelector = createSelector(
    state => state.get("userList"),
    userList => userList.map(user => ({
        'Username': user["user_name"],
        'Email': user['user_emailid'],
        'Phone Number': user['user_phonenumber'],
        'User Role': user['userrole'],
        'Password': user['user_password'],
        'Client Id': user['client_id'],
        'Id': user['id'],
        'Created Date':user['created_date'],
        'Updated Date': user['updated_date'],
    }))
)

export const userRoleListSelector = createSelector(
    state => state.get("userRoleList"),
    userRoleList => userRoleList
)

export const currentTabSelector = createSelector(
    state => state.get("currentTab"),
    currentTab => currentTab
)
export const currentInventoryFileSelector = createSelector(
    state => state.get("currentInventoryFile"),
    currentInventoryFile => currentInventoryFile
)
export const buyersSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) => {
        try {
            return [...new Set(inventoryRawData.map((item) => item['Buyer']))].sort();
        } catch (e) {
            console.error(e);
            return [];
        }

    }
);
export const enginesSelector = createSelector(
    (state) => state.get('inventoryRawData'),
    (inventoryRawData) => {
        try {
            return [
                ...new Set(inventoryRawData.map((item) => item['Uf ASI Item Engine'])),
            ].sort();
        } catch (e) {
            console.error(e);
            return [];
        }
    }
);
export const partsSelector = createSelector(
    (state) => state.get('demandRawData'),
    (demandRawData) => {
        try {
            return (demandRawData['Predictions - 24 Months']) ? [
                ...new Set(
                    demandRawData['Predictions - 24 Months'].map(
                        (item) => item['Part_Number']
                    ).concat(demandRawData['(8) Un-Forecastable Listing'].map(
                        (item) => item['Part Number']
                    ))
                ),
            ].sort() : []
        } catch (e) {
            console.error(e);
            return [];
        }
    }
);
export const customersSelector = createSelector(
    (state) => state.get('demandRawData'),
    (demandRawData) => {
        try {
            return (demandRawData['Predictions - 24 Months']) ? [
                ...new Set(
                    demandRawData['Predictions - 24 Months'].map(
                        (item) => item['Customer']
                    ).concat(demandRawData['(8) Un-Forecastable Listing'].map(
                        (item) => item['Customer']
                    ))
                ),
            ].sort() : []
        } catch (e) {
            console.error(e);
            return [];
        }
    }
);
export const loginCompleteSelector = createSelector(
    state => state.get("loginComplete"),
    loginComplete => loginComplete
)
