import axios from 'axios';

const isProduction = process.env.REACT_APP_IS_PRODUCTION;
const baseUrl = process.env.REACT_APP_BASE_URL;

const headers = {
  'Content-Type': 'application/json',
  'X-XSS-Protection': 1,
  'X-Content-Type-Options': 'nosniff',
  'Access-Control-Allow-Origin': '*',
};

export function loginWithCredentials(client, user, password) {
  const loginUrl = isProduction? `${baseUrl}/foreopticsLogin`: '/api/foreopticsLogin';
  const payload = {
    CLIENTNAME: client,
    USERNAME: user,
    PASSWORD: password,
  };
  const options = {
    method: 'POST',
    headers: headers,
    data: JSON.stringify(payload),
    url: loginUrl,
  };
  return axios(options);
}

export function getInventoryRawData(fileName, token) {
  const inventoryRawDataUrl = isProduction? `${baseUrl}/foreopticsinventoryrawdata`: '/api/foreopticsinventoryrawdata';
  const payload = {
    history_file_name: fileName,
  };

  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token },
    data: JSON.stringify(payload),
    url: inventoryRawDataUrl,
  };

  return axios(options);
}

export function uploadInputFile(filedata,selectedRadioButton, token) {

  const formData = new FormData();
  formData.append('file', filedata, filedata.name);
  formData.append('authorization', token);
  formData.append('Selectedradiobutton', selectedRadioButton)

  const uploadUrl = isProduction? `${baseUrl}/Upload`: '/api/Upload';


  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token, 'Content-Type': 'multipart/form-data' },
    url: uploadUrl,
    data: formData
  };
  return axios(options);
}

export function getFileStatus(token) {
  const fileStatusUrl = isProduction? `${baseUrl}/foreoptics_filestatus`: '/api/foreoptics_filestatus';


  const options = {
    method: 'GET',
    headers: { ...headers, authorization: token },
    url: fileStatusUrl,
  };

  return axios(options);
}

export function getInventoryAnalysis(
  buyerFilterlist,
  engineFilterList,
  fileName,
  token
) {

  const inventoryAnalysisUrl = isProduction? `${baseUrl}/foreopticssheetsZone`: '/api/foreopticssheetsZone';


  const payload = {
    buyerfilter: buyerFilterlist,
    enginefilter: engineFilterList,
    history_file_name: fileName,
  };

  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token, extension: false },
    data: JSON.stringify(payload),
    url: inventoryAnalysisUrl,
  };

  return axios(options);
}

export function createUserEntries(user, token) {
  const userEntriesUrl = isProduction? `${baseUrl}/userentries`: '/api/userentries';

  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token },
    data: JSON.stringify(user),
    url: userEntriesUrl,
  };

  return axios(options);
}

export function updateUserEntries(user, token) {
  const userEntriesUpdateUrl = isProduction? `${baseUrl}/userentries_update`: '/api/userentries_update';

  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token },
    data: JSON.stringify(user),
    url: userEntriesUpdateUrl,
  };

  return axios(options);
}

export function deleteUserEntries(user, token) {
  const userEntriesDeleteUrl = isProduction? `${baseUrl}/userentries_delete`: '/api/userentries_delete';

  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token },
    data: JSON.stringify(user),
    url: userEntriesDeleteUrl,
  };

  return axios(options);
}

export function getUserDataTable(token) {
  const userDataUrl = isProduction? `${baseUrl}/get_table_userdata`: '/api/get_table_userdata';

  const options = {
    method: 'GET',
    headers: { ...headers, authorization: token },
    url: userDataUrl,
  };

  return axios(options);
}

export function getUserRoleDataTable(token) {
  const userRoleDataUrl = isProduction? `${baseUrl}/get_table_userroledata`: '/api/get_table_userroledata';

  const options = {
    method: 'GET',
    headers: { ...headers, authorization: token },
    url: userRoleDataUrl,
  };

  return axios(options);
}

export function getDemandForecastData(fileName, tabName, token) {
  const demandForecastDataUrl = isProduction? `${baseUrl}/foreopticsDemandData`: '/api/foreopticsDemandData';

  const payload = {
    tabname: tabName,
    history_file_name: fileName,
  };

  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token },
    data: JSON.stringify(payload),
    url: demandForecastDataUrl,
  };

  return axios(options);
}

export function getHistoryFileDetails(clientId, userName, token) {
  const historyFileDetailsUrl = isProduction? `${baseUrl}/get_history_file_details`: '/api/get_history_file_details';

  const payload = {
    client_id: clientId,
    username: userName,
  };

  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token },
    data: JSON.stringify(payload),
    url: historyFileDetailsUrl,
  };

  return axios(options);
}

export function createCompany(details, token) {
  const companyOnboardingUrl = isProduction? `${baseUrl}/companyOnbording`: '/api/companyOnbording';


  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token },
    data: JSON.stringify(details),
    url: companyOnboardingUrl,
  };

  return axios(options);
}

export function updateCompany(details, token) {
  const updateCompanyUrl = isProduction? `${baseUrl}/updateCompany`: '/api/updateCompany';


  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token },
    data: JSON.stringify(details),
    url: updateCompanyUrl,
  };

  return axios(options);
}

export function deleteCompany(details, token) {
  const deleteCompanyUrl = isProduction? `${baseUrl}/deleteCompany`: '/api/deleteCompany';


  const options = {
    method: 'POST',
    headers: { ...headers, authorization: token },
    data: JSON.stringify(details),
    url: deleteCompanyUrl,
  };

  return axios(options);
}

export function getCompanyDetails(token) {
  const companyDetailsUrl = isProduction? `${baseUrl}/getCompanyDetails`: '/api/getCompanyDetails';

  const options = {
    method: 'GET',
    headers: { ...headers, authorization: token },
    url: companyDetailsUrl,
  };

  return axios(options);
}
