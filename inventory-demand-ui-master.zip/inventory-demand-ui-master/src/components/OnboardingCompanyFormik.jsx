import * as React from 'react';
import {useFormik} from 'formik';
import {Button, Grid, Paper} from '@material-ui/core';
import Typography from "@material-ui/core/Typography";
import {
    BusinessRounded,
    DeleteRounded,
    EditRounded,
    Face, HomeRounded,
    MailOutline,
    Phone, PowerSettingsNewRounded,
    Visibility,
    VpnKey
} from "@material-ui/icons";
import TableWithExport from "./TableWithExport";
import {useDispatch, useSelector} from "react-redux";
import {companyListSelector} from "../selectors";
import IconButton from "@material-ui/core/IconButton";
import * as Yup from 'yup';
import _ from 'lodash';
import RadioButtonRow from "./RadioButtonRow";
import TextField from "@material-ui/core/TextField";
import {useState} from "react";
import {updateCompany, addCompany, deleteCompany} from "../actions";
import Box from "@material-ui/core/Box";

const validationSchema = Yup.object({
    company: Yup.string().required("Required"),
    name: Yup.string().max(16, "Maximum 16 characters").required("Required"),
    password: Yup.string().required("Required"),
    email: Yup.string().email().required("Required"),
    confirmPassword: Yup.string()
        .required("Required")
        .oneOf(
            [Yup.ref('password'), null],
            'Passwords must match',
        ),
    status: Yup.string().required("Required"),
})


const radioData = [
    {title: 'Active', name: 'A'},
    {title: 'Inactive', name: 'I'}
]

const tableColumns = (editCompany, deleteCompany) => [
    {"name": 'Company', "label": "Company"},
    {"name": 'Admin Username', "label": "Admin Username"},
    {"name": 'Email', "label": "Email"},
    {"name": 'Address', "label": "Address"},
    {"name": 'Phone Number', "label": "Phone Number"},
    {"name": 'Status', "label": "Status"},
    {
        "name": 'Action', "label": "Action", options: {
            customBodyRender: (value, {rowData}) =>
                <div style={{display: "flex", flexDirection: "row"}}>
                    <IconButton color="primary" aria-label="edit company" component="span"
                                onClick={() => editCompany(rowData[0])}>
                        <EditRounded/>
                    </IconButton>
                    <IconButton color="primary" aria-label="delete company" component="span"
                                onClick={() => deleteCompany(rowData[0])}>
                        <DeleteRounded/>
                    </IconButton>
                </div>
        }
    }
];

const options = {
    filterType: 'checkbox',
    search: true,
    filter: false,
    print: false,
    selectableRowsHeader: false,
    selectableRowsHideCheckboxes: true,
    viewColumns: false,
    download: false
};

export default function OnboardingCompanyFormik({classes}) {

    const [isEditing, setEditing] = useState(false);
    const companyList = useSelector(companyListSelector);

    const delCompany = (companyName) => {
        const companyDetails = _.find(companyList, (o) => o['Company'] === companyName);
        const company = {
            client_name: companyDetails['Company']
        }

        setTimeout(() => {
            dispatch(deleteCompany(company))
        }, 300);

    }

    const dispatch = useDispatch();

    const editCompany = (company) => {
        setEditing(true);
        const {'Admin Username': Name, Company, Address, Email, "Phone Number": phNumber, Status} = _.find(companyList, (o) => o['Company'] === company);
        setFieldValue('name', Name);
        setFieldValue('phNumber', phNumber);
        setFieldValue('email', Email);
        setFieldValue('status', Status === 'Active' ? 'A' : 'I');
        setFieldValue('company', Company);
        setFieldValue('address', Address);
        setFieldValue('password', 'password');
        setFieldValue('confirmPassword', 'password');
    }

    const {handleSubmit, handleChange, values, errors, isValid, dirty, setFieldValue, resetForm} = useFormik({
            initialValues: {
                company: '',
                address: '',
                name: '',
                email: '',
                password: '',
                confirmPassword: '',
                phNumber: '',
                status: 'A'
            },
            validationSchema,
            onSubmit(values, {setSubmitting}) {
                let company = {
                    company: values.company,
                    email: values.email,
                    name: values.name,
                    phonenumber: values.phNumber,
                    status: values.status,
                    address: values.address
                };

                if (isEditing) {
                    setTimeout(() => {
                        setSubmitting(false);
                        dispatch(updateCompany(company));
                    }, 300);
                } else {
                    company['password'] = values.password;
                    company['confirmpassword'] = values.confirmPassword;
                    setTimeout(() => {
                        setSubmitting(false);
                        dispatch(addCompany(company));
                    }, 300);
                }

                setEditing(false);
                resetForm();
            }
        }
    );

    return (

        <Grid container justify={"flex-start"} spacing={2}>
            <Box width={'30%'}>
                <Grid item style={{padding: 20}}>
                    <Paper className={classes.padding}>
                        <form className={classes.margin} style={{padding: 20}} onSubmit={handleSubmit}>


                            <Grid container spacing={8} justify="center">
                                <Grid item md={true} sm={true} xs={true}>
                                    <Typography variant={'h6'}
                                                align={"center"}>{isEditing ? 'Edit Company' : 'Add New Company'}</Typography>
                                </Grid>
                            </Grid>

                            <Grid container spacing={8} alignItems="flex-end">
                                <Grid item>
                                    <BusinessRounded/>
                                </Grid>
                                <Grid item md={true} sm={true} xs={true}>
                                    <TextField id="company"
                                               label="Company"
                                               type="text"
                                               fullWidth
                                               autoFocus
                                               required
                                               onChange={handleChange}
                                               value={values.company}
                                               error={!_.isEmpty(errors.company)}
                                               helperText={!_.isEmpty(errors.company) && errors.company}
                                               disabled={isEditing}
                                    />
                                </Grid>
                            </Grid>

                            <Grid container spacing={8} alignItems="flex-end">
                                <Grid item>
                                    <Face/>
                                </Grid>
                                <Grid item md={true} sm={true} xs={true}>
                                    <TextField id="name"
                                               label="Admin Username"
                                               type="text"
                                               fullWidth
                                               autoFocus
                                               required
                                               onChange={handleChange}
                                               value={values.name}
                                               error={!_.isEmpty(errors.name)}
                                               helperText={!_.isEmpty(errors.name) && errors.name}
                                               disabled={isEditing}
                                    />
                                </Grid>
                            </Grid>

                            <Grid container spacing={8} alignItems="flex-end">
                                <Grid item>
                                    <MailOutline/>
                                </Grid>
                                <Grid item md={true} sm={true} xs={true}>
                                    <TextField id="email"
                                               label="Email"
                                               type="email"
                                               fullWidth
                                               autoFocus
                                               required
                                               onChange={handleChange}
                                               value={values.email}
                                               error={!_.isEmpty(errors.email)}
                                               helperText={!_.isEmpty(errors.email) && errors.email}
                                    />
                                </Grid>
                            </Grid>

                            {!isEditing && <Grid container spacing={8} alignItems="flex-end">
                                <Grid item>
                                    <VpnKey/>
                                </Grid>
                                <Grid item md={true} sm={true} xs={true}>
                                    <TextField id="password"
                                               label="Password"
                                               type="password"
                                               fullWidth
                                               autoFocus
                                               required
                                               onChange={handleChange}
                                               value={values.password}
                                               error={!_.isEmpty(errors.password)}
                                               helperText={!_.isEmpty(errors.password) && errors.password}
                                    />
                                </Grid>
                            </Grid>}

                            {!isEditing && <Grid container spacing={8} alignItems="flex-end">
                                <Grid item>
                                    <Visibility/>
                                </Grid>
                                <Grid item md={true} sm={true} xs={true}>
                                    <TextField id="confirmPassword"
                                               label="Confirm Password"
                                               type="text"
                                               fullWidth
                                               autoFocus
                                               required
                                               onChange={handleChange}
                                               value={values.confirmPassword}
                                               error={!_.isEmpty(errors.confirmPassword)}
                                               helperText={!_.isEmpty(errors.confirmPassword) && errors.confirmPassword}
                                    />
                                </Grid>
                            </Grid>}

                            <Grid container spacing={8} alignItems="flex-end">
                                <Grid item>
                                    <HomeRounded/>
                                </Grid>
                                <Grid item md={true} sm={true} xs={true}>
                                    <TextField id="address"
                                               label="Address"
                                               type="text"
                                               fullWidth
                                               autoFocus
                                               onChange={handleChange}
                                               value={values.address}
                                    />
                                </Grid>
                            </Grid>


                            <Grid container spacing={8} alignItems="flex-end">
                                <Grid item>
                                    <Phone/>
                                </Grid>
                                <Grid item md={true} sm={true} xs={true}>
                                    <TextField id="phNumber"
                                               label="Phone Number"
                                               type="text"
                                               fullWidth
                                               autoFocus
                                               onChange={handleChange}
                                               value={values.phNumber}
                                    />
                                </Grid>
                            </Grid>

                            <Grid container spacing={8} alignItems="flex-end">
                                <Grid item>
                                    <PowerSettingsNewRounded/>
                                </Grid>
                                <Grid item md={true} sm={true} xs={true}>
                                    <RadioButtonRow data={radioData}
                                                    value={values.status}
                                                    handleChange={handleChange}
                                                    name={'status'}
                                    />
                                </Grid>
                            </Grid>

                            <Grid container justify="center" style={{marginTop: '20px'}}>
                                <Button
                                    variant="contained"
                                    color="primary"
                                    type={'submit'}
                                    disabled={!isValid || !dirty}
                                >
                                    Submit
                                </Button>
                            </Grid>

                        </form>
                    </Paper>
                </Grid>
            </Box>
            <Box width={'65%'}>
                <Grid item style={{padding: 20}}>
                    <TableWithExport data={companyList} title={'Company Details'}
                                     columns={tableColumns(editCompany, delCompany)}
                                     options={options}/>
                </Grid>
            </Box>
        </Grid>
    );
}
