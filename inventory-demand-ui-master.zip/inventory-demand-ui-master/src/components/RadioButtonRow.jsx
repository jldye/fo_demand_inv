import FormControl from "@material-ui/core/FormControl";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import React from "react";
import Typography from "@material-ui/core/Typography";


export default function RadioButtonRow({data, value, handleChange, name='radio-button-row'}) {
    return (
        <FormControl component="fieldset">
            <RadioGroup aria-label="file type" name={name} value={value} onChange={handleChange}>
                <div style={{display: "flex", flexDirection: "row"}}>
                    {data.map((item) => (
                        <FormControlLabel key={item.name} value={item.name} control={<Radio color={"primary"}/>}
                                          label={<Typography style={{fontSize: 15}}>{item.title}</Typography>}/>
                    ))}
                </div>
            </RadioGroup>
        </FormControl>

    )
}
