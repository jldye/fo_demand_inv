import * as React from 'react';
import {useFormik} from 'formik';
import {Button, Grid, Paper} from '@material-ui/core';
import Typography from "@material-ui/core/Typography";
import {
    DeleteRounded,
    EditRounded,
    Face,
    MailOutline,
    Phone,
    SupervisorAccount,
    Visibility,
    VpnKey
} from "@material-ui/icons";
import TableWithExport from "./TableWithExport";
import {useDispatch, useSelector} from "react-redux";
import {userDetailsSelector, userListSelector, userRoleListSelector} from "../selectors";
import IconButton from "@material-ui/core/IconButton";
import * as Yup from 'yup';
import _ from 'lodash';
import RadioButtonRow from "./RadioButtonRow";
import TextField from "@material-ui/core/TextField";
import {useState} from "react";
import {addUser, updateUser, deleteUser} from "../actions";

const validationSchema = Yup.object({
    username: Yup.string().max(16, "Maximum 16 characters").required("Required"),
    password: Yup.string().required("Required"),
    email: Yup.string().email().required("Required"),
    confirmPassword: Yup.string()
        .required("Required")
        .oneOf(
            [Yup.ref('password'), null],
            'Passwords must match',
        ),
    userRole: Yup.string().required("Required"),
})


const radioData = [
    {title: 'Admin', name: 'admin'},
    {title: 'User', name: 'user'}
]

const tableColumns = (editUser, deleteUser) => [
    {"name": 'Username', "label": "Username"},
    {"name": 'Email', "label": "Email"},
    {"name": 'Phone Number', "label": "Phone Number"},
    {"name": 'User Role', "label": "User Role"},
    {
        "name": 'Action', "label": "Action", options: {
            customBodyRender: (value, {rowData}) =>
                <React.Fragment>
                    <IconButton color="primary" aria-label="edit user" component="span"
                                onClick={() => editUser(rowData[0])}>
                        <EditRounded/>
                    </IconButton>
                    <IconButton color="primary" aria-label="delete user" component="span"
                                onClick={() => deleteUser(rowData[0])}>
                        <DeleteRounded/>
                    </IconButton>
                </React.Fragment>
        }
    }
];

const options = {
    filterType: 'checkbox',
    search: true,
    filter: false,
    print: false,
    selectableRowsHeader: false,
    selectableRowsHideCheckboxes: true,
    viewColumns: false,
    download: false
};

export default function OnboardingUserFormik({classes}) {

    const [isEditing, setEditing] = useState(false);
    const userList = useSelector(userListSelector);
    const userRoleList = useSelector(userRoleListSelector);
    const userDetails = useSelector(userDetailsSelector);

    const delUser = (username) => {
        const userDetails = _.find(userList, (o) => o.Username === username);
        const user = {
            id: userDetails['Id']
        }

        setTimeout(() => {
            dispatch(deleteUser(user))
        }, 300);

    }

    const dispatch = useDispatch();
    const getUserRoleId = (userRole) => _.find(userRoleList, (o) => (o['role_name'] === userRole))['id'];

    const editUser = (username) => {
        setEditing(true);
        const {Username, Email, "Phone Number": phNumber, "User Role": userRole, Password} = _.find(userList, (o) => o.Username === username);
        setFieldValue('username', Username);
        setFieldValue('phNumber', phNumber);
        setFieldValue('email', Email);
        setFieldValue('userRole', userRole);
        setFieldValue('password', Password);
        setFieldValue('confirmPassword', Password);
    }

    const {handleSubmit, handleChange, values, errors, isValid, dirty, setFieldValue, resetForm} = useFormik({
            initialValues: {
                username: '',
                email: '',
                password: '',
                confirmPassword: '',
                phNumber: '',
                userRole: 'admin'
            },
            validationSchema,
            onSubmit(values, {setSubmitting}) {
                let user = {
                    user_emailid: values.email,
                    user_name: values.username,
                    user_password: values.password,
                    user_phonenumber: values.phNumber,
                    user_roleid: getUserRoleId(values.userRole),
                    userrole: values.userRole
                };

                if (isEditing) {
                    const userDetails = _.find(userList, (o) => o.Username === values.username)
                    user['client_id'] = userDetails['Client Id'];
                    user['id'] = userDetails['Id'];
                    setTimeout(() => {
                        setSubmitting(false);
                        dispatch(updateUser(user));
                    }, 300);
                } else {
                    user['client_id'] = userDetails.clientid;
                    setTimeout(() => {
                        setSubmitting(false);
                        dispatch(addUser(user));
                    }, 300);
                }

                setEditing(false);
                resetForm();
            }
        }
    );

    return (

        <Grid container justify={"flex-start"} spacing={8} style={{margin: 15}}>
            <Grid item style={{padding: 20}}>
                <Paper className={classes.padding}>
                    <form className={classes.margin} style={{padding: 20}} onSubmit={handleSubmit}>


                        <Grid container spacing={8} justify="center">
                            <Grid item md={true} sm={true} xs={true}>
                                <Typography variant={'h6'} align={"center"}>{isEditing?'Edit User':'Add New User'}</Typography>
                            </Grid>
                        </Grid>

                        <Grid container spacing={8} alignItems="flex-end">
                            <Grid item>
                                <Face/>
                            </Grid>
                            <Grid item md={true} sm={true} xs={true}>
                                <TextField id="username"
                                           label="Username"
                                           type="text"
                                           fullWidth
                                           autoFocus
                                           required
                                           onChange={handleChange}
                                           value={values.username}
                                           error={!_.isEmpty(errors.username)}
                                           helperText={!_.isEmpty(errors.username) && errors.username}
                                           disabled={isEditing}
                                />
                            </Grid>
                        </Grid>

                        <Grid container spacing={8} alignItems="flex-end">
                            <Grid item>
                                <MailOutline/>
                            </Grid>
                            <Grid item md={true} sm={true} xs={true}>
                                <TextField id="email"
                                           label="Email"
                                           type="email"
                                           fullWidth
                                           autoFocus
                                           required
                                           onChange={handleChange}
                                           value={values.email}
                                           error={!_.isEmpty(errors.email)}
                                           helperText={!_.isEmpty(errors.email) && errors.email}
                                />
                            </Grid>
                        </Grid>

                        {!isEditing && <Grid container spacing={8} alignItems="flex-end">
                            <Grid item>
                                <VpnKey/>
                            </Grid>
                            <Grid item md={true} sm={true} xs={true}>
                                <TextField id="password"
                                           label="Password"
                                           type="password"
                                           fullWidth
                                           autoFocus
                                           required
                                           onChange={handleChange}
                                           value={values.password}
                                           error={!_.isEmpty(errors.password)}
                                           helperText={!_.isEmpty(errors.password) && errors.password}
                                />
                            </Grid>
                        </Grid>}

                        {!isEditing && <Grid container spacing={8} alignItems="flex-end">
                            <Grid item>
                                <Visibility/>
                            </Grid>
                            <Grid item md={true} sm={true} xs={true}>
                                <TextField id="confirmPassword"
                                           label="Confirm Password"
                                           type="text"
                                           fullWidth
                                           autoFocus
                                           required
                                           onChange={handleChange}
                                           value={values.confirmPassword}
                                           error={!_.isEmpty(errors.confirmPassword)}
                                           helperText={!_.isEmpty(errors.confirmPassword) && errors.confirmPassword}
                                />
                            </Grid>
                        </Grid>}

                        <Grid container spacing={8} alignItems="flex-end">
                            <Grid item>
                                <Phone/>
                            </Grid>
                            <Grid item md={true} sm={true} xs={true}>
                                <TextField id="phNumber"
                                           label="Phone Number"
                                           type="text"
                                           fullWidth
                                           autoFocus
                                           onChange={handleChange}
                                           value={values.phNumber}
                                />
                            </Grid>
                        </Grid>

                        <Grid container spacing={8} alignItems="flex-end">
                            <Grid item>
                                <SupervisorAccount/>
                            </Grid>
                            <Grid item md={true} sm={true} xs={true}>
                                <RadioButtonRow data={radioData}
                                                value={values.userRole}
                                                handleChange={handleChange}
                                                name={'userRole'}
                                />
                            </Grid>
                        </Grid>

                        <Grid container justify="center" style={{marginTop: '20px'}}>
                            <Button
                                variant="contained"
                                color="primary"
                                type={'submit'}
                                disabled={!isValid || !dirty}
                            >
                                Submit
                            </Button>
                        </Grid>

                    </form>
                </Paper>
            </Grid>
            <Grid item style={{padding: 20}}>
                <TableWithExport data={userList} title={'User Details'} columns={tableColumns(editUser, delUser)}
                                 options={options}/>
            </Grid>
        </Grid>
    );
}
