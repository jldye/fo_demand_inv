import React from 'react';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Checkbox from "@material-ui/core/Checkbox";
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';

const icon = <CheckBoxOutlineBlankIcon fontSize="small"/>;
const checkedIcon = <CheckBoxIcon fontSize="small"/>;

export default function ComboBox({label, placeholder, data, selectedOption, setSelectedOption}) {
    return (
        <Autocomplete
            size={"small"}
            id="combo-box-demo"
            multiple={true}
            limitTags={0}
            options={data}
            disableCloseOnSelect
            getOptionLabel={(option) => option}
            value={selectedOption}
            onChange={(e, option) => {
                setSelectedOption(option);
            }}
            renderOption={(option, {selected}) => {
                return (<React.Fragment>
                    <Checkbox
                        icon={icon}
                        checkedIcon={checkedIcon}
                        style={{marginRight: 8}}
                        checked={selected}
                    />
                    {option}
                </React.Fragment>)
                }
            }
            renderTags={(value, getTagProps) => ` + ${selectedOption.length}`}

            style={{width: 200}}
            renderInput={(params) => (
                <TextField {...params} variant="outlined" label={label} placeholder={placeholder}/>
            )}/>
    );
}
