import React from 'react';
import {
    BrowserRouter as Router,
    Switch,
    Route
} from "react-router-dom";
import {Provider} from 'react-redux'
import DrawerContainer from "../components/DrawerContainer";
import {getStore} from "../utility/getStore";
import ProtectedRoute from "./ProtectedRoute";
import LoginScreen from "../screens/LoginScreen";
import {ThemeProvider} from "@material-ui/styles";
import CssBaseline from "@material-ui/core/CssBaseline";
import {theme} from '../ui';

const store = getStore();

function App() {
    return (

        <ThemeProvider theme={theme}>
            <CssBaseline/>
            <Provider store={store}>
                <Router>
                    <Switch>
                        <Route path="/login">
                            <LoginScreen/>
                        </Route>
                        <ProtectedRoute path="/">
                            <DrawerContainer/>
                        </ProtectedRoute>
                    </Switch>
                </Router>
            </Provider>
        </ThemeProvider>
    );
}

export default App;
