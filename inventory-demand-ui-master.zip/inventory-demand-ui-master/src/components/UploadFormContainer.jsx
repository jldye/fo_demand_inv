import React, {useState, useCallback} from 'react';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import {useDropzone} from 'react-dropzone';
import Button from "@material-ui/core/Button";
import clsx from "clsx";
import RadioButtonRow from "./RadioButtonRow";
import prettyBytes from 'pretty-bytes';
import {uploadFile} from "../actions";
import {useDispatch} from "react-redux";

export default function UploadFormContainer({open, handleDialogClose, classes}) {

    const [isLoading, setLoading] = useState(false);
    const [currentOption, setCurrentOption] = useState('Inventory');

    const [myFiles, setMyFiles] = useState([])

    const onDrop = useCallback(acceptedFiles => {
        setLoading(true);
        setMyFiles([...acceptedFiles]);
    }, [])

    const radioData = [
        {name: "Inventory", title: "Inventory"},
        {name: "Demand", title: "Demand"}
    ]
    let {getRootProps, getInputProps} = useDropzone({
        accept: '.xlsx, .csv',
        multiple: false,
        onDropAccepted: () => setLoading(false),
        onDropRejected: () => setLoading(false),
        onDrop: onDrop
    });

    const files = myFiles.map(file => (
        <li key={file.name}>
            {file.name} - {prettyBytes(file.size)}
        </li>
    ));

    const handleRadioChange = (event) => {
        setCurrentOption(event.target.value);
    };
    const dispatch = useDispatch();

    const onSubmit = () => {
        dispatch(uploadFile(myFiles[0], currentOption))
        setMyFiles([])
        handleDialogClose();
    }

    const handleClose = () => {
        setMyFiles([]);
        handleDialogClose();
    }

    return (
        <Dialog open={open} onClose={handleDialogClose} aria-labelledby="form-dialog-title">
            <DialogTitle id="form-dialog-title">Upload File</DialogTitle>
            <DialogContent>
                <DialogContentText>
                    Upload an excel sheet or csv file containing the raw data.

                    <RadioButtonRow data={radioData} handleChange={handleRadioChange} value={currentOption}/>

                </DialogContentText>

                <section className="container">
                    <div {...getRootProps({className: clsx(classes.dropzone)})}>
                        <input {...getInputProps()} />
                        <p>Drag 'n' drop a file here, or click to select files</p>
                    </div>
                    <aside>
                        <ul><h4>{!isLoading ? files : 'Uploading'}</h4></ul>
                    </aside>
                </section>

            </DialogContent>
            <DialogActions>
                <Button onClick={handleClose} color="primary">
                    Cancel
                </Button>
                <Button onClick={onSubmit} color="primary" disabled={!(myFiles.length > 0)}>
                    Confirm
                </Button>
            </DialogActions>
        </Dialog>
    );
}
