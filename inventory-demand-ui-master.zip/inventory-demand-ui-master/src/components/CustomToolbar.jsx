import React from "react";
import Tooltip from "@material-ui/core/Tooltip";
import IconButton from "@material-ui/core/IconButton";
import ExcelIcon from "../icons/ExcelIcon";
import CsvIcon from "../icons/CsvIcon";

export default function CustomToolbar({classes, handleCsvExport, HandleExcelExport}) {

    return (
        <React.Fragment>
            <Tooltip title={"CSV Download"}>
                <IconButton onClick={handleCsvExport}>
                    <CsvIcon/>
                </IconButton>
            </Tooltip>
            <Tooltip title={"Excel Download"}>
                <IconButton onClick={HandleExcelExport}>
                    <ExcelIcon/>
                </IconButton>
            </Tooltip>
        </React.Fragment>
    );
}
