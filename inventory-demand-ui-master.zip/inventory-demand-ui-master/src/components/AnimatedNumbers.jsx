import React from 'react';
import AnimatedNumber from 'react-animated-number';

export default function ({bigValue}) {
    return (
        <AnimatedNumber component="text" value={bigValue}
            style={{
                transition: '0.8s ease-out',
                fontSize: 48,
                transitionProperty:
                    'background-color, color, opacity'
            }}
            frameStyle={perc => (
                perc === 100 ? {} : {backgroundColor: '#ffeb3b'}
            )}
            stepPrecision={0}
            />
    )
}