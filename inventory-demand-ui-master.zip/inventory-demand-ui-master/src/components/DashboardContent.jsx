import React from "react";
import DemandDashboard from "../screens/DemandDashboard";
import InventoryDashboard from "../screens/InventoryDashboard";
import {Switch} from "react-router-dom";
import ProtectedRoute from "./ProtectedRoute";


export default function DashboardContent({classes}) {
    return (
        <div className={classes.content}>
            <Switch>
                <ProtectedRoute exact={true} path="/demand">
                    <DemandDashboard classes={classes}/>
                </ProtectedRoute>
                <ProtectedRoute exact={true} path="/">
                    { <InventoryDashboard classes={classes}/> }
                </ProtectedRoute>
            </Switch>
        </div>
    );
}
