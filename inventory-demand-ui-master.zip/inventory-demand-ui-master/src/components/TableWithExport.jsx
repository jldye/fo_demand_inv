import MUIDataTable from "mui-datatables";
import React from "react";
import CustomToolbar from "./CustomToolbar";
import {ExportToCsv} from 'export-to-csv';
import zipcelx from 'zipcelx';
import _ from 'lodash';

export default function TableWithExport({data, columns, title, options}) {

    const defaultOptions = {
        filterType: 'checkbox',
        search: true,
        filter: false,
        print: false,
        selectableRowsHeader: false,
        selectableRowsHideCheckboxes: true,
        viewColumns: false,
        selectableRows: 'single',
        selectableRowsOnClick: true,
        selectToolbarPlacement: 'none',
        download: false,
        customToolbar: () => {
            return (
                <CustomToolbar handleCsvExport={handleCsvExport} HandleExcelExport={handleExcelExport}/>
            );
        }
    };


    function getDataForExport() {

        const filteredColumns = columns.map(a => a.name);

        let result = [(Object.keys(data[0])
                .filter(a => _.includes(filteredColumns, a))
                .map(a => ({
                    value: a,
                    type: 'string'
                }))
        )];

        let result2 = data.map(row => {
            let entry = []
            for (const prop in row) {
                if (_.includes(filteredColumns, prop)) {
                    entry.push({value: row[prop], type: Number.isFinite(row[prop]) ? 'number' : 'string'})
                }
            }
            return entry
        })

        console.log(result);
        console.log(result2);
        return result.concat(result2);

    }

    function handleExcelExport() {
        const config = {
            filename: title,
            sheet: {
                data: getDataForExport()
            }
        };
        zipcelx(config);
    }

    function handleCsvExport() {

        const options = {
            fieldSeparator: ',',
            quoteStrings: '"',
            decimalSeparator: '.',
            showLabels: true,
            useTextFile: false,
            useBom: true,
            useKeysAsHeaders: true,
            filename: title
        };

        const csvExporter = new ExportToCsv(options);
        csvExporter.generateCsv(data);
    }


    return (
        <MUIDataTable
            title={title}
            data={data}
            columns={columns}
            options={{...defaultOptions, ...options}}

        />
    );
}

