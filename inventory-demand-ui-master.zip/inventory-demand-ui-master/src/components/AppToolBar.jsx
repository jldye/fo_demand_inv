import clsx from "clsx";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import Typography from "@material-ui/core/Typography";
import AppBar from "@material-ui/core/AppBar";
import React from "react";
import UserMenu from "./UserMenu";
import Grid from "@material-ui/core/Grid";
import {useStyles} from "../utility/stylesGenerator";


export default function AppToolBar({handleDrawerOpen, open}) {
    const classes = useStyles();
    return (
        <AppBar
            position="fixed"
            className={clsx(classes.appBar, {
                [classes.appBarShift]: open,
            })}
        >
            <Toolbar>
                <Grid container justify={'space-between'} alignItems={'center'}>
                    <Grid item>
                        <IconButton
                            color="inherit"
                            aria-label="open drawer"
                            onClick={handleDrawerOpen}
                            edge="start"
                            className={clsx(classes.menuButton, {
                                [classes.hide]: open,
                            })}
                        >
                            <MenuIcon/>
                        </IconButton>
                    </Grid>
                    <Grid item>
                        <Typography variant="h6" noWrap>
                            FOREOPTICS
                        </Typography>
                    </Grid>
                    <Grid item>
                        <UserMenu classes={classes}/>
                    </Grid>
                </Grid>
            </Toolbar>
        </AppBar>)
}
