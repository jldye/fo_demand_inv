import React from 'react';
import Box from '@material-ui/core/Box';
import DashboardContent from "./DashboardContent";
import UploadFormContainer from "./UploadFormContainer";
import DataTableContainer from "./DataTableContainer";
import {useSelector} from "react-redux";
import {currentTabSelector} from "../selectors";
import _ from 'lodash';
import TabToolbar from "./TabToolbar";

function TabPanel(props) {
    const {children, value, index, ...other} = props;
    return (
        <div
            role="tabpanel"
            hidden={_.indexOf(tabsList.map(a => a.name), value) !== index}
            id={`nav-tabpanel-${index}`}
            aria-labelledby={`nav-tab-${index}`}
            {...other}
        >
            {_.indexOf(tabsList.map(a => a.name), value) === index && (
                <Box>
                    {children}
                </Box>
            )}
        </div>
    );
}


const tabsList = [{name: "Dashboard", Component: DashboardContent}, {name: "Data", Component: DataTableContainer}];

export default function TabNavigationContainer({classes}) {
    const currentTab = useSelector(currentTabSelector);
    const [open, setOpen] = React.useState(false);

    const handleClose = () => {
        setOpen(false);
    };

    return (
        <main className={classes.content}>
            <div className={classes.toolbar}/>
            <TabToolbar currentTab={currentTab} setOpen={setOpen} tabsList={tabsList}/>
            {
                tabsList.map((tab, index) => {
                        return <TabPanel value={currentTab} index={index} key={index}>
                            <tab.Component classes={classes}/>
                        </TabPanel>
                    }
                )
            }
            <UploadFormContainer open={open} handleDialogClose={handleClose} classes={classes}/>
        </main>
    )
}
