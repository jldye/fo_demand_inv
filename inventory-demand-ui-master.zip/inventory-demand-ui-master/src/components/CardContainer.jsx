import Card from "@material-ui/core/Card";
import CardContent from "@material-ui/core/CardContent";
import Typography from "@material-ui/core/Typography";
import React from "react";
import CardActions from "@material-ui/core/CardActions";
import CircularProgress from "@material-ui/core/CircularProgress";

export default function CardContainer({classes, text, secondaryText, isReady}) {
    return (
        <Card className={classes.root} variant="outlined">
            <CardContent>
                <Typography variant={"caption"} color="textPrimary" gutterBottom>
                    {text}
                </Typography>
                <Typography variant={"h4"} color="primary" gutterBottom>
                    {!isReady ? <CircularProgress size={30}/> : secondaryText}
                </Typography>
            </CardContent>
            <CardActions>
            </CardActions>
        </Card>
    )
};
