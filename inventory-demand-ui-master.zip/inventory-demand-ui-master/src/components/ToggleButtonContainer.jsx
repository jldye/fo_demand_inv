import React from 'react';
import ButtonGroup from "@material-ui/core/ButtonGroup";
import Button from "@material-ui/core/Button";

export default function ToggleButtonContainer
    ({data, current, handleCurrent}) {
    return (
        <ButtonGroup
            value={current}
            aria-label="text alignment"
            variant="contained" color="primary"
        >
            {data.map((item => (
                <Button value={item} key={item} aria-label={item} onClick={handleCurrent}
                        color={current === item ? "primary" : "secondary"}>
                    {item}
                </Button>
            )))}
        </ButtonGroup>
    );
}
