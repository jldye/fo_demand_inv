import React from 'react'
import {ResponsiveLine} from '@nivo/line'

const commonProperties = {
    margin: {top: 40, right: 40, bottom: 40, left: 40},
    animate: true,
    enableSlices: 'x',
}

export default function TimeSeriesLineComponent({data, colors}) {

    return (
        <div style={{height: 500}}>
            <ResponsiveLine
                {...commonProperties}
                data={data}
                colors={colors}
                xScale={{
                    type: 'time',
                    format: '%Y-%m-%d',
                    useUTC: false,
                    precision: 'day',
                }}
                xFormat="time:%Y-%m"
                yFormat={",.2f"}
                yScale={{
                    type: 'linear',
                    stacked: false,
                }}
                axisLeft={{
                    legend: 'Quantity',
                    legendOffset: -35,
                    position: 'middle'
                }}
                axisBottom={{
                    format: '%b %Y',
                    tickValues: 'every 2 months',
                    legend: 'Time',
                    legendOffset: 35,
                    position: 'middle'
                }}
                curve={'linear'}
                enablePointLabel={false}
                pointSize={10}
                pointBorderWidth={1}
                pointBorderColor={{
                    from: 'color',
                    modifiers: [['darker', 0.3]],
                }}
                useMesh={true}
                enableSlices={false}

                legends={[
                    {
                        anchor: 'top',
                        direction: 'row',
                        justify: false,
                        translateX: 160,
                        translateY: -40,
                        itemsSpacing: 2,
                        itemWidth: 100,
                        itemHeight: 20,
                        itemDirection: 'left-to-right',
                        itemOpacity: 0.85,
                        symbolSize: 20,
                        effects: [
                            {
                                on: 'hover',
                                style: {
                                    itemOpacity: 1
                                }
                            }
                        ]
                    }
                ]}

            />
        </div>
    )
}
