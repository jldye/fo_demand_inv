import {ResponsiveBar} from '@nivo/bar'
import React from "react";
import numeral from 'numeral';
import {theme} from '../../ui';
// make sure parent container have a defined height when using
// responsive component, otherwise height will be 0 and
// no chart will be rendered.
// website examples showcase many properties,
// you'll often use just a few of them.

const defaultData = [
    {
        "Zone": "A1",
        "Target": 64,
        "Estimate": 93,
    },
    {
        "Zone": "A2",
        "Target": 79,
        "Estimate": 20,
    },
    {
        "Zone": "A3",
        "Target": 50,
        "Estimate": 12,
    },
    {
        "Zone": "B1",
        "Target": 80,
        "Estimate": 66,
    },
    {
        "Zone": "B2",
        "Target": 31,
        "Estimate": 77,
    },
    {
        "Zone": "B3",
        "Target": 96,
        "Estimate": 71,
    },
    {
        "Zone": "C1",
        "Target": 24,
        "Estimate": 37,
    }
]
const defaultKeys = ['Target', 'Estimate'];
export default function GroupedBarChartComponent({
                                                     data = defaultData,
                                                     height = 500,
                                                     keys = defaultKeys,
                                                     indexBy = "Zone",
                                                     xAxis = 'Zone',
                                                     colors = [theme.palette.primary.main, theme.palette.secondary.main],
                                                     groupMode = "grouped",
                                                     anchor = 'bottom-right',
                                                     translateX = 120,
                                                     translateY = 0,
                                                     displayOptions
                                                 }) {
    return (
        <div style={{height: height}}>
            <ResponsiveBar
                data={data}
                keys={keys}
                indexBy={indexBy}
                margin={{top: 50, right: 130, bottom: 50, left: 60}}
                groupMode={groupMode}
                colors={colors}
                borderColor={{from: 'color', modifiers: [['darker', 1.6]]}}
                axisTop={null}
                axisRight={null}
                axisBottom={{
                    tickSize: 5,
                    tickPadding: 5,
                    tickRotation: 0,
                    legend: xAxis,
                    legendPosition: 'middle',
                    legendOffset: 32
                }}
                axisLeft={{
                    tickSize: 5,
                    tickPadding: 5,
                    tickRotation: 0,
                    legend: displayOptions.yAxis,
                    legendPosition: 'middle',
                    legendOffset: -40,
                    format: displayOptions.format
                }}
                labelSkipWidth={12}
                labelSkipHeight={12}
                labelTextColor={{from: 'color', modifiers: [['darker', 1.6]]}}
                legends={[
                    {
                        dataFrom: 'keys',
                        anchor: anchor,
                        direction: 'column',
                        justify: false,
                        translateX: translateX,
                        translateY: translateY,
                        itemsSpacing: 2,
                        itemWidth: 100,
                        itemHeight: 20,
                        itemDirection: 'left-to-right',
                        itemOpacity: 0.85,
                        symbolSize: 20,
                        effects: [
                            {
                                on: 'hover',
                                style: {
                                    itemOpacity: 1
                                }
                            }
                        ]
                    }
                ]}
                animate={true}
                motionStiffness={90}
                motionDamping={15}
                enableLabel={false}
                tooltipFormat={value => numeral(value).format('0.00')}
                tooltip={displayOptions.tooltip}

            />
        </div>);
}
