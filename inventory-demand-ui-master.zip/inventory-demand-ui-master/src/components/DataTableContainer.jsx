import React from "react";
import InventoryData from "../screens/InventoryData";
import {Switch} from "react-router-dom";
import ProtectedRoute from "./ProtectedRoute";
import DemandData from "../screens/DemandData";


export default function DataTableContainer({classes}) {
    return (
        <div className={classes.content}>
            <Switch>
                <ProtectedRoute exact={true} path="/demand">
                    <DemandData classes={classes}/>
                </ProtectedRoute>
                <ProtectedRoute exact={true} path="/">
                    <InventoryData classes={classes}/>
                </ProtectedRoute>
            </Switch>
        </div>
    );
}
