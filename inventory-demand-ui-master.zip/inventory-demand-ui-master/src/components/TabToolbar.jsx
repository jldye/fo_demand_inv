import React from "react";
import Grid from "@material-ui/core/Grid";
import Tabs from "@material-ui/core/Tabs";
import {Switch} from "react-router-dom";
import ProtectedRoute from "./ProtectedRoute";
import ComboBox from "./ComboBox";
import Button from "@material-ui/core/Button";
import Tab from "@material-ui/core/Tab";
import {useDispatch, useSelector} from "react-redux";
import {
    buyersSelector,
    currentBuyersInventoryDashboardSelector, currentCustomersDemandDashboardSelector,
    currentEnginesInventoryDashboardSelector,
    currentPartsDemandDashboardSelector,
    customersSelector,
    enginesSelector,
    partsSelector
} from "../selectors";
import {
    setCurrentBuyersInventoryDashboard,
    setCurrentCustomersDemandDashboard,
    setCurrentEnginesInventoryDashboard, setCurrentPartsDemandDashboard, setCurrentTab
} from "../actions";
import Box from "@material-ui/core/Box";

function a11yProps(index) {
    return {
        id: `nav-tab-${index}`,
        'aria-controls': `nav-tabpanel-${index}`,
    };
}

function LinkTab(props) {
    return (
        <Tab
            component="a"
            onClick={(event) => {
                event.preventDefault();
            }}
            {...props}
        />
    );
}

export default function TabToolbar({currentTab, tabsList, setOpen}) {
    const buyers = useSelector(buyersSelector);
    const engines = useSelector(enginesSelector);
    const parts = useSelector(partsSelector);
    const customers = useSelector(customersSelector);
    const dispatch = useDispatch();

    const currentBuyersInventoryDashboard = useSelector(currentBuyersInventoryDashboardSelector);
    const currentEnginesInventoryDashboard = useSelector(currentEnginesInventoryDashboardSelector);

    const currentPartsDemandDashboard = useSelector(currentPartsDemandDashboardSelector);
    const currentCustomersDemandDashboard = useSelector(currentCustomersDemandDashboardSelector);


    const handleClickOpen = () => {
        setOpen(true);
    };


    function setBuyers(buyers) {
        dispatch(setCurrentBuyersInventoryDashboard(buyers));
    }

    function setEngines(engines) {
        dispatch(setCurrentEnginesInventoryDashboard(engines));
    }

    function setCustomers(customers) {
        dispatch(setCurrentCustomersDemandDashboard(customers));
    }

    function setParts(parts) {
        dispatch(setCurrentPartsDemandDashboard(parts));
    }

    const handleTabChange = (event, newValue) => {
        dispatch(setCurrentTab(newValue));
    };

    return (
        <Box width={'100%'}>
            <Grid container justify={'space-between'} alignItems={'center'} spacing={1}>
                <Grid item>
                    <Tabs
                        value={currentTab}
                        onChange={handleTabChange}
                        aria-label="nav tabs example"
                    >
                        {tabsList.map((tab, index) =>
                            <LinkTab key={tab.name} value={tab.name} label={tab.name} {...a11yProps(index)} />
                        )}
                    </Tabs>
                </Grid>
                <Grid item>
                    <Switch>
                        <ProtectedRoute exact={true} path="/demand">
                            <ComboBox label={'Part'} placeholder={'Part'}
                                      data={parts}
                                      selectedOption={currentPartsDemandDashboard}
                                      setSelectedOption={setParts}

                            />
                        </ProtectedRoute>
                        <ProtectedRoute exact={true} path="/">
                            <ComboBox label={'Buyer'} placeholder={'Buyer'} data={buyers}
                                      selectedOption={currentBuyersInventoryDashboard}
                                      setSelectedOption={setBuyers}/>
                        </ProtectedRoute>
                    </Switch>
                </Grid>
                <Grid item>
                    <Switch>
                        <ProtectedRoute exact={true} path="/demand">
                            <ComboBox label={'Customer'} placeholder={'Customer'}
                                      data={customers}
                                      selectedOption={currentCustomersDemandDashboard}
                                      setSelectedOption={setCustomers}
                            />
                        </ProtectedRoute>
                        <ProtectedRoute exact={true} path="/">
                            <ComboBox label={'Engine'} placeholder={'Engine'} data={engines}
                                      selectedOption={currentEnginesInventoryDashboard}
                                      setSelectedOption={setEngines}
                            />
                        </ProtectedRoute>
                    </Switch>
                </Grid>
                <Grid item>
                    <Button variant="contained" color="primary" onClick={handleClickOpen}>
                        Upload
                    </Button>
                </Grid>
            </Grid>
        </Box>
    )
}
