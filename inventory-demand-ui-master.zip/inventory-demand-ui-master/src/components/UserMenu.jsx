import IconButton from "@material-ui/core/IconButton";
import React from "react";
import {AccountCircle} from "@material-ui/icons";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import {useDispatch, useSelector} from "react-redux";
import {attemptLogout} from "../actions";
import Typography from "@material-ui/core/Typography";
import {userDetailsSelector} from "../selectors";
import {useHistory} from "react-router-dom";


export default function UserMenu({classes}) {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const dispatch = useDispatch();
    const userDetails = useSelector(userDetailsSelector);
    const history = useHistory();

    const handleMenu = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <React.Fragment>
            <IconButton
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleMenu}
                color="inherit"
            >
                <AccountCircle/>
                {userDetails && <Typography style={{marginLeft: 5}}>{userDetails.username}</Typography>}
            </IconButton>
            <Menu
                id="user-menu"
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
            >
                <MenuItem onClick={() => dispatch(attemptLogout(history))}>Logout</MenuItem>
            </Menu>
        </React.Fragment>
    );
}
