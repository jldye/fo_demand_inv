import React from 'react';
import AppToolBar from "./AppToolBar";
import MiniDrawer from "./MiniDrawer";
import {theme} from '../ui';
import TabNavigationContainer from "./TabNavigationContainer";
import ProtectedRoute from "./ProtectedRoute";
import HistoryDetails from "../screens/HistoryDetails";
import {useStyles} from "../utility/stylesGenerator";
import {useLocation} from "react-router-dom";
import OnBoarding from "../screens/OnBoarding";
import _ from 'lodash';
import {useSelector} from "react-redux";
import {userDetailsSelector} from "../selectors";
import {AddCircleOutline, DynamicFeed, History, TrendingUp} from "@material-ui/icons";

export default function DrawerContainer() {
    const location = useLocation();
    const [open, setOpen] = React.useState(false);
    const {userrole} = useSelector(userDetailsSelector);

    const handleDrawerOpen = () => {
        setOpen(true);
    };

    const handleDrawerClose = () => {
        setOpen(false);
    };

    const classes = useStyles();

    const screensList = {
        admin: [
        {link: '/', icon: <DynamicFeed/>, name: 'Inventory'},
        {link: '/demand', icon: <TrendingUp/>, name: 'Demand'},
        {link: '/history', icon: <History/>, name: 'History'},
        {link: '/onboarding', icon: <AddCircleOutline/>, name: 'Add User', divider: true}
        ],
        user: [
            {link: '/', icon: <DynamicFeed/>, name: 'Inventory'},
            {link: '/demand', icon: <TrendingUp/>, name: 'Demand'},
            {link: '/history', icon: <History/>, name: 'History'}
        ],
        superadmin: [
            {link: '/onboarding', icon: <AddCircleOutline/>, name: 'Add Company'}
        ]

    }

    return (
            <div style={{display: "flex"}}>
                <MiniDrawer theme={theme}
                            handleDrawerClose={handleDrawerClose}
                            open={open}
                            screensList={screensList[userrole]}
                            classes={classes}
                />
                <AppToolBar open={open} handleDrawerOpen={handleDrawerOpen}/>
                {!_.includes (['/history', '/onboarding'], location.pathname) && <TabNavigationContainer classes={classes}/>}
                <ProtectedRoute exact={true} path="/history">
                    { <HistoryDetails classes={classes}/> }
                </ProtectedRoute>
                <ProtectedRoute exact={true} path="/onboarding">
                    { <OnBoarding classes={classes}/> }
                </ProtectedRoute>
            </div>
    );
}
