import {fromJS} from 'immutable';

export const defaultState = fromJS({
    userDetails: {},
    currentInventoryFile: '',
    currentDemandFile: '',
    loginComplete: false,
    currentTab: 'Dashboard',
    loadingInventoryRawData: false,
    currentOptionInventoryDashboard: 'Service Level',
    inventoryRawData: [],
    currentBuyersInventoryDashboard: [],
    currentEnginesInventoryDashboard: [],
    inventoryDataRadioOption: 'Inventory Analysis',
    inventoryDataToggleOption: 'Zone',
    userList: [],
    userRoleList: [],
    companyList: [],
    loadingDemandRawData: false,
    currentOptionDemandDashboard: 'Full Period',
    demandRawData: {},
    currentPartsDemandDashboard: [],
    currentCustomersDemandDashboard: [],
    demandDataRadioOption: 'Forecast Accuracy',
    demandDataToggleOption: 'Part/Customer',
    historyFileDetails: []
});
