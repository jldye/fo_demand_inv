import Color from 'color';

export const getColorGradient = (theme) => {
  const mainColor = Color(theme.palette.primary.main);

  return [
    mainColor.lighten(0.5).hex(),
    mainColor.lighten(0.3).hex(),
    mainColor.lighten(0.1).hex(),
    mainColor.hex(),
    mainColor.darken(0.1).hex(),
    mainColor.darken(0.3).hex(),
    mainColor.darken(0.5).hex(),
  ];
};

export const getTwoColors = (theme) => {
  const mainColor = Color(theme.palette.primary.main);
  const secondaryColor = Color(theme.palette.secondary.main);
  return [mainColor.hex(), secondaryColor.hex()];
};
