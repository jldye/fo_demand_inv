import _ from 'lodash';
import moment from "moment";

export function sumOfNaRM(data, columnName) {
    let sumOfColumn = 0;
    data.forEach((jsonObject) => {
        const value = jsonObject[columnName];
        if (value !== '') {
            sumOfColumn = sumOfColumn + Number(value);
        }
    });
    return sumOfColumn;
}

export function checkForValid(value) {
    if (value === Infinity || value === undefined || value.toString() === 'NaN') {
        value = '';
    }
    return value;
}

export function meanOfNaRM(data, columnName) {
    return _.meanBy(data, function (item) {
        return Number(item[columnName]);
    });
}

export function roundOfNaRM(value) {
    return Math.round(value);
}

export function distinctItem(data, columnName) {
    const distinctItem = _.chain(data)
        .sortBy(columnName)
        .map(function (rows) {
            const date = new Date(rows[columnName]);
            const month =
                date.getDate() + '-' + date.getMonth() + '-' + date.getFullYear();
            rows['month'] = month;
            return rows;
        })
        .groupBy(function (row) {
            return '~' + row['month'];
        })
        .map(function (rows) {
            return rows[0]['month'];
        })
        .value();
    return distinctItem;
}

export function formatCurrencyRoundWithoutZero(total) {
    let neg = false;
    if (total < 0) {
        neg = true;
        total = Math.abs(total);
    }
    return (
        (neg ? '-$' : '$') +
        roundOfNaRM(parseFloat(total))
            .toFixed(0)
            .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
            .toString()
    );
}

export function changeDateFormat(date) {
    return moment(date).format('YYYY-MM-DD');
}

export function formatCurrencyRoundWithZero(total) {
    let neg = false;
    if (total < 0) {
        neg = true;
        total = Math.abs(total);
    }
    return (neg ? '-$' : '$') + roundOfNaRM(parseFloat(total))
        .toFixed(2)
        .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
        .toString();
}
