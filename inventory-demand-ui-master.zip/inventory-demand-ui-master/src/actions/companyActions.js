import {makeActionCreator} from "../utility";

export const UPDATE_COMPANY = 'UPDATE_COMPANY';
export const DELETE_COMPANY = 'DELETE_COMPANY';
export const ADD_COMPANY = 'ADD_COMPANY';
export const GET_COMPANY_LIST = 'GET_COMPANY_LIST';
export const SET_COMPANY_LIST = 'SET_COMPANY_LIST';

export const updateCompany = makeActionCreator(UPDATE_COMPANY, 'company');
export const deleteCompany = makeActionCreator(DELETE_COMPANY, 'company');
export const addCompany = makeActionCreator(ADD_COMPANY, 'company');
export const getCompanyList = makeActionCreator(GET_COMPANY_LIST);
export const setCompanyList = makeActionCreator(SET_COMPANY_LIST, 'companyList');
