import { makeActionCreator } from '../utility';

export const GET_DEMAND_RAW_DATA = 'GET_DEMAND_RAW_DATA';
export const SET_DEMAND_RAW_DATA = 'SET_DEMAND_RAW_DATA';
export const SET_LOADING_DEMAND_RAW_DATA = 'SET_LOADING_DEMAND_RAW_DATA';
export const SET_CURRENT_OPTION_DEMAND_DASHBOARD =
  'SET_CURRENT_OPTION_DEMAND_DASHBOARD';
export const SET_CURRENT_CUSTOMERS_DEMAND_DASHBOARD =
  'SET_CURRENT_CUSTOMERS_DEMAND_DASHBOARD';
export const SET_CURRENT_PARTS_DEMAND_DASHBOARD =
  'SET_CURRENT_PARTS_DEMAND_DASHBOARD';

export const SET_DEMAND_DATA_RADIO_OPTION = 'SET_DEMAND_DATA_RADIO_OPTION';
export const SET_DEMAND_DATA_TOGGLE_OPTION = 'SET_DEMAND_DATA_TOGGLE_OPTION';

export const getDemandRawData = makeActionCreator(
  GET_DEMAND_RAW_DATA,
  'fileName',
  'tabName'
);
export const setDemandRawData = makeActionCreator(
  SET_DEMAND_RAW_DATA,
  'demandRawData',
  'tabName'
);
export const setLoadingDemandRawData = makeActionCreator(
  SET_LOADING_DEMAND_RAW_DATA,
  'loadingDemandRawData'
);
export const setCurrentOptionDemandDashboard = makeActionCreator(
  SET_CURRENT_OPTION_DEMAND_DASHBOARD,
  'currentOptionDemandDashboard'
);

export const setCurrentCustomersDemandDashboard = makeActionCreator(
  SET_CURRENT_CUSTOMERS_DEMAND_DASHBOARD,
  'currentCustomersDemandDashboard'
);
export const setCurrentPartsDemandDashboard = makeActionCreator(
  SET_CURRENT_PARTS_DEMAND_DASHBOARD,
  'currentPartsDemandDashboard'
);
export const setDemandDataRadioOption = makeActionCreator(
  SET_DEMAND_DATA_RADIO_OPTION,
  'demandDataRadioOption'
);
export const setDemandDataToggleOption = makeActionCreator(
  SET_DEMAND_DATA_TOGGLE_OPTION,
  'demandDataToggleOption'
);
