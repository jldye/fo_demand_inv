import {makeActionCreator} from "../utility";

export const GET_INVENTORY_RAW_DATA = 'GET_INVENTORY_RAW_DATA';
export const SET_INVENTORY_RAW_DATA = 'SET_INVENTORY_RAW_DATA';
export const APPEND_INVENTORY_RAW_DATA = 'APPEND_INVENTORY_RAW_DATA';
export const SET_LOADING_INVENTORY_RAW_DATA = 'SET_LOADING_INVENTORY_RAW_DATA';
export const SET_CURRENT_OPTION_INVENTORY_DASHBOARD = 'SET_CURRENT_OPTION_INVENTORY_DASHBOARD';
export const SET_CURRENT_BUYERS_INVENTORY_DASHBOARD = 'SET_CURRENT_BUYERS_INVENTORY_DASHBOARD';
export const SET_CURRENT_ENGINES_INVENTORY_DASHBOARD = 'SET_CURRENT_ENGINES_INVENTORY_DASHBOARD';

export const SET_INVENTORY_DATA_RADIO_OPTION = 'SET_INVENTORY_DATA_RADIO_OPTION';
export const SET_INVENTORY_DATA_TOGGLE_OPTION = 'SET_INVENTORY_DATA_TOGGLE_OPTION';


export const getInventoryRawData = makeActionCreator(GET_INVENTORY_RAW_DATA, "fileName");
export const setInventoryRawData = makeActionCreator(SET_INVENTORY_RAW_DATA, "inventoryRawData");
export const appendInventoryRawData = makeActionCreator(APPEND_INVENTORY_RAW_DATA, "inventoryRawData");
export const setLoadingInventoryRawData = makeActionCreator(SET_LOADING_INVENTORY_RAW_DATA, "loadingInventoryRawData");
export const setCurrentOptionInventoryDashboard = makeActionCreator(SET_CURRENT_OPTION_INVENTORY_DASHBOARD, "currentOptionInventoryDashboard");

export const setCurrentBuyersInventoryDashboard = makeActionCreator(SET_CURRENT_BUYERS_INVENTORY_DASHBOARD, "currentBuyersInventoryDashboard");
export const setCurrentEnginesInventoryDashboard = makeActionCreator(SET_CURRENT_ENGINES_INVENTORY_DASHBOARD, "currentEnginesInventoryDashboard");
export const setInventoryDataRadioOption = makeActionCreator(SET_INVENTORY_DATA_RADIO_OPTION, "inventoryDataRadioOption");
export const setInventoryDataToggleOption = makeActionCreator(SET_INVENTORY_DATA_TOGGLE_OPTION, "inventoryDataToggleOption");


