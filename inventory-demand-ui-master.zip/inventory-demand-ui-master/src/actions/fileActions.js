import { makeActionCreator } from '../utility';

export const SET_CURRENT_INVENTORY_FILE = 'SET_CURRENT_INVENTORY_FILE';
export const SET_CURRENT_DEMAND_FILE = 'SET_CURRENT_DEMAND_FILE';
export const UPLOAD_FILE = 'UPLOAD_FILE';
export const GET_FILE_STATUS = 'GET_FILE_STATUS';
export const GET_HISTORY_FILE_DETAILS = 'GET_HISTORY_FILE_DETAILS';
export const SET_HISTORY_FILE_DETAILS = 'SET_HISTORY_FILE_DETAILS';

export const setCurrentInventoryFile = makeActionCreator(
  SET_CURRENT_INVENTORY_FILE,
  'currentInventoryFile'
);
export const setCurrentDemandFile = makeActionCreator(
  SET_CURRENT_DEMAND_FILE,
  'currentDemandFile'
);
export const uploadFile = makeActionCreator(
  UPLOAD_FILE,
  'file',
  'selectedOption'
);
export const getFileStatus = makeActionCreator(GET_FILE_STATUS);
export const getHistoryFileDetails = makeActionCreator(
  GET_HISTORY_FILE_DETAILS
);
export const setHistoryFileDetails = makeActionCreator(
  SET_HISTORY_FILE_DETAILS,
  'historyFileDetails'
);
