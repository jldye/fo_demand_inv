import {makeActionCreator} from "../utility";

export const LOGIN = 'LOGIN';
export const SET_USER_DATA = 'SET_USER_DATA';
export const LOGOUT = 'LOGOUT';
export const SET_LOGIN_COMPLETE = 'SET_LOGIN_COMPLETE';
export const SET_CURRENT_TAB = 'SET_CURRENT_TAB';

export const GET_USER_LIST = 'GET_USER_LIST';
export const SET_USER_LIST = 'SET_USER_LIST';
export const SET_USER_ROLE_LIST = 'SET_USER_ROLE_LIST';

export const UPDATE_USER = 'UPDATE_USER';
export const DELETE_USER = 'DELETE_USER';
export const ADD_USER = 'ADD_USER';

export const attemptLogin = makeActionCreator(LOGIN, 'client', 'user', 'password', 'history', 'from');
export const setUserDetails = makeActionCreator(SET_USER_DATA, 'userDetails');
export const attemptLogout = makeActionCreator(LOGOUT,'history');
export const setLoginComplete = makeActionCreator(SET_LOGIN_COMPLETE,'loginComplete');
export const setCurrentTab = makeActionCreator(SET_CURRENT_TAB, 'currentTab');

export const getUserList = makeActionCreator(GET_USER_LIST);
export const setUserList = makeActionCreator(SET_USER_LIST, 'userList');
export const setUserRoleList = makeActionCreator(SET_USER_ROLE_LIST, 'userRoleList');

export const updateUser = makeActionCreator(UPDATE_USER, 'user');
export const deleteUser = makeActionCreator(DELETE_USER, 'user');
export const addUser = makeActionCreator(ADD_USER, 'user');

