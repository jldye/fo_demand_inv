import React from "react";
import RadioButtonRow from "../components/RadioButtonRow";
import Toolbar from "@material-ui/core/Toolbar";
import Grid from "@material-ui/core/Grid";
import ToggleButtonContainer from "../components/ToggleButtonContainer";
import TableWithExport from "../components/TableWithExport";
import {useDispatch, useSelector} from "react-redux";
import {
    demandDataRadioOptionSelector,
    demandDataToggleOptionSelector,
    groupByPartAndCustomerFASelector,
    groupByPartFASelector,
    groupByCustomerFASelector,
    demandHistorySelector,
    demandHistoryExceptionSelector,
    forecastableDemandSelector,
    unforecastableDemandSelector,
    modelDemandSelector,
    groupByPartAndCustomerPredictionsSelector,
    groupByPartPredictionsSelector,
    groupByCustomerPredictionsSelector
} from "../selectors";
import {
    setDemandDataRadioOption,
    setDemandDataToggleOption
} from "../actions";
import _ from 'lodash';
import moment from 'moment';
import numeral from "numeral";


const toggleButtonData = [
    "Part/Customer",
    "Part",
    "Customer",
]

const radioButtonData = [
    {name: "Forecast Accuracy", title: "Forecast Accuracy"},
    {name: "Predictions", title: "Predictions"},
    {name: "Full History", title: "Full History"},
    {name: "Exception Report", title: "Exception Report"},
    {name: "Forecastable List", title: "Forecastable List"},
    {name: "Unforecastable List", title: "Unforecastable List"},
    {name: "Model Details", title: "Model Details"}
]

const stringOptions =  {
    customBodyRender: (value) => `${numeral(value).format('0,0.00')}`,
    sortCompare: (order) => {
        return (obj1, obj2) => {
            let val1 = parseInt(obj1.data, 10);
            let val2 = parseInt(obj2.data, 10);
            return (val1 - val2) * (order === 'asc' ? 1 : -1);
        };
    }
}

const numberOptions =  {
    customBodyRender: (value) => `${numeral(value).format('0,0.00')}`,
}

const percentOptions =  {
    customBodyRender: (value) => `${numeral(value).format('0,0.00')}%`,
}


const getColumns = () => ({
    "Forecast Accuracy": {
        "Part/Customer": [
            {name: "Part", label: "Part"},
            {name: "Customer", label: "Customer"},
            {name: "Length_of_Measurement_Period_Months", label: "Length Of Measurement Period (Months)"},
            {name: "Gross_Margin_Full_Period", label: "Gross Margin (Full Period) ($)", options: numberOptions},
            {name: "Forecast_Quantity_FullPeriod", label: "Forecast Quantity (Full Period)"},
            {name: "Actual_Quantity_FullPeriod", label: "Actual Quantity (Full Period)"},
            {name: "fa_full_period", label: "Forecast Accuracy (Full Period)", options: percentOptions},
            {name: "fa_6_month", label: "Forecast Accuracy (Rolling 6 months)", options: percentOptions},
            {name: "fa_3_month", label: "Forecast Accuracy (Rolling 3 months)", options: percentOptions}
        ],
        "Part": [
            {name: "Part", label: "Part"},
            {name: "Length_of_Measurement_Period_Months", label: "Length Of Measurement Period (Months)"},
            {name: "Gross_Margin_Full_Period", label: "Gross Margin (Full Period) ($)", options: numberOptions},
            {name: "Forecast_Quantity_FullPeriod", label: "Forecast Quantity (Full Period)"},
            {name: "Actual_Quantity_FullPeriod", label: "Actual Quantity (Full Period)"},
            {name: "fa_full_period", label: "Forecast Accuracy (Full Period)", options: percentOptions},
            {name: "fa_6_month", label: "Forecast Accuracy (Rolling 6 months)", options: percentOptions},
            {name: "fa_3_month", label: "Forecast Accuracy (Rolling 3 months)", options: percentOptions}
        ],
        "Customer": [
            {name: "Customer", label: "Customer"},
            {name: "Length_of_Measurement_Period_Months", label: "Length Of Measurement Period (Months)"},
            {name: "Gross_Margin_Full_Period", label: "Gross Margin (Full Period) ($)", options: numberOptions},
            {name: "Forecast_Quantity_FullPeriod", label: "Forecast Quantity (Full Period)"},
            {name: "Actual_Quantity_FullPeriod", label: "Actual Quantity (Full Period)"},
            {name: "fa_full_period", label: "Forecast Accuracy (Full Period)", options: percentOptions},
            {name: "fa_6_month", label: "Forecast Accuracy (Rolling 6 months)", options: percentOptions},
            {name: "fa_3_month", label: "Forecast Accuracy (Rolling 3 months)", options: percentOptions}
        ]
    },
    "Predictions": {
        "Part/Customer": [
            {name: "Part_Number", label: "Part"},
            {name: "Customer", label: "Customer"},

        ],
        "Part": [
            {name: "Part_Number", label: "Part"},
        ],
        "Customer": [
            {name: "Customer", label: "Customer"},
        ]

    },
    "Full History": [

        {name: "Part_Number", label: "Part"},
        {name: "Customer", label: "Customer"},
        {name: "Received_Date", label: "Received Date"},
        {name: "Quantity", label: "Quantity"},
        {name: "Gross_Margin", label: "Gross Margin ($)", options: stringOptions},

    ],
    "Exception Report": [

        {name: "Part_Number", label: "Part"},
        {name: "Customer", label: "Customer"},
        {name: "Received_Date", label: "Received Date"},
        {name: "Quantity", label: "Quantity"},
        {name: "Gross_Margin", label: "Gross Margin ($)", options: stringOptions},
        {name: "Alert", label: "Alert"},
        {name: "Lower_Bound", label: "Exception-Lower Bound"},
        {name: "Upper_Bound", label: "Exception-Upper Bound"},
    ],
    "Forecastable List": [
        {name: "Part_Number", label: "Part"},
        {name: "Customer", label: "Customer"},
        {name: "Gross_Margin", label: "Gross Margin (12 Month) ($)", options: stringOptions}
    ],
    "Unforecastable List": [
        {name: "Part_Number", label: "Part"},
        {name: "Customer", label: "Customer"},
        {name: "Gross_Margin", label: "Gross Margin (12 Month) ($)", options: stringOptions}
    ],
    "Model Details": [
        {name: "Part", label: "Part"},
        {name: "Customer", label: "Customer"},
        {name: "Selected_Model", label: "Selected Model"},
        {name: "Gross_Margin", label: "Gross Margin (12 Period) ($)", options: stringOptions},
        {name: "Actual_Demand_Whole_Period", label: "Actual Demand (Whole period)", options: stringOptions},
        {name: "Forecast_Demand_Whole_Period", label: "Forecast Demand (Whole period)", options: percentOptions},
        {name: "Forecast_Accuracy_Whole_Period", label: "Forecast Accuracy (Whole period)", options: percentOptions},
        {name: "Forecast_Accuracy_Running_6_Month", label: "Forecast Accuracy (Running 6 Months)", options: percentOptions},
        {name: "Forecast_Accuracy_Running_3_Month", label: "Forecast Accuracy (Running 3 Months)", options: percentOptions},
        {name: "Mean_Average_Error_Point_Forecast", label: "Mean Average Error (Point Forecast)", options: stringOptions}
    ]
})

export default function DemandData() {
    const dispatch = useDispatch();
    const radioOption = useSelector(demandDataRadioOptionSelector);
    const toggleOption = useSelector(demandDataToggleOptionSelector);

    const groupByPartAndCustomerFA = useSelector(groupByPartAndCustomerFASelector);
    const groupByPartFA = useSelector(groupByPartFASelector);
    const groupByCustomerFA = useSelector(groupByCustomerFASelector);

    const demandHistory = useSelector(demandHistorySelector);
    const demandHistoryException = useSelector(demandHistoryExceptionSelector);

    const unforecastableDemand = useSelector(unforecastableDemandSelector);
    const forecastableDemand = useSelector(forecastableDemandSelector);
    const modelDemand = useSelector(modelDemandSelector);
    const predictionsByPartAndCustomer = useSelector(groupByPartAndCustomerPredictionsSelector);
    const predictionsByPart = useSelector(groupByPartPredictionsSelector);
    const predictionsByCustomer = useSelector(groupByCustomerPredictionsSelector);

    let columns = getColumns();

    const handleRadioChange = (event) => {
        dispatch(setDemandDataRadioOption(event.target.value));
    };

    const handleToggleChange = (event) => {
        dispatch(setDemandDataToggleOption(event.currentTarget.value))
    };

    const dataOptions = {
        "Forecast Accuracy": {
            "Part/Customer": groupByPartAndCustomerFA,
            "Part": groupByPartFA,
            "Customer": groupByCustomerFA,
        },
        "Predictions": {
            "Part/Customer": predictionsByPartAndCustomer,
            "Part": predictionsByPart,
            "Customer": predictionsByCustomer,
        },
        "Full History": demandHistory,
        "Exception Report": demandHistoryException,
        "Forecastable List": forecastableDemand,
        "Unforecastable List": unforecastableDemand,
        "Model Details": modelDemand
    }

    if (radioOption === 'Predictions') {
        const keys = Object.keys(dataOptions[radioOption][toggleOption][0])

        let yearKeys = keys.filter(key => key.startsWith('Total')).sort();
        let remaining = keys.filter(key => !_.includes(yearKeys, key) && !_.includes(['Part_Number', 'Customer', 'Grand Total'], key));

        remaining = remaining.sort((a, b) => new moment(a, 'MMM YYYY') - new moment(b, 'MMM YYYY'))
        _.forEach(remaining, (a) => columns[radioOption][toggleOption].push({name: a, label: a}))

        _.forEach(yearKeys, (a) => columns[radioOption][toggleOption].push({name: a, label: a}))

        columns[radioOption][toggleOption].push({name: "Grand Total", label: "Grand Total"});

    }


    return (
        <React.Fragment>
            <Toolbar>

                <Grid container justify={"center"}>
                    <Grid item>
                        <RadioButtonRow data={radioButtonData}
                                        value={radioOption}
                                        handleChange={handleRadioChange}/>
                    </Grid>
                </Grid>

            </Toolbar>
            <Toolbar style={{paddingRight: 0, paddingBottom: 20}}>
                {!_.includes(['Full History', 'Exception Report'
                    , 'Forecastable List', 'Unforecastable List', 'Model Details'], radioOption) &&
                <Grid container justify={"flex-end"}>
                    <Grid item><ToggleButtonContainer data={toggleButtonData}
                                                      handleCurrent={handleToggleChange}
                                                      current={toggleOption}/>
                    </Grid>
                </Grid>}
            </Toolbar>
            <TableWithExport columns={_.includes(['Full History', 'Exception Report'
                , 'Forecastable List', 'Unforecastable List', 'Model Details'], radioOption) ?
                columns[radioOption] : columns[radioOption][toggleOption]}
                             data={_.includes(['Full History', 'Exception Report'
                                 , 'Forecastable List', 'Unforecastable List', 'Model Details'], radioOption) ?
                                 dataOptions[radioOption] : dataOptions[radioOption][toggleOption]}
                             title={radioOption}/>
        </React.Fragment>
    );
}
