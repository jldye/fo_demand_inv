import React from "react";
import OnboardingUserFormik from "../components/OnboardingUserFormik";
import OnboardingCompanyFormik from "../components/OnboardingCompanyFormik";
import {useSelector} from "react-redux";
import {userDetailsSelector} from "../selectors";

export default function ({classes}) {
    const {userrole} = useSelector(userDetailsSelector);

    return (
        <main className={classes.content}>
            <div className={classes.toolbar}/>
            {userrole === 'admin' && <OnboardingUserFormik classes={classes}/>}
            {userrole === 'superadmin' && <OnboardingCompanyFormik classes={classes}/>}
        </main>
    )
}
