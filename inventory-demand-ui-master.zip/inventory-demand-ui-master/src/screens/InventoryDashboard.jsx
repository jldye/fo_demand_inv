import React from 'react';
import Grid from "@material-ui/core/Grid";
import CardContainer from "../components/CardContainer";
import {useSelector, useDispatch} from "react-redux";
import {
    averageInventoryPerMonthSelector,
    cycleStockPerMonthSelector,
    overageInventoryPerMonthSelector,
    safetyStockPerMonthSelector,
    serviceLevelSelector,
    turnsPerYearSelector,
    inventoryRawDataSelector,
    currentDashboardDataSelector
} from "../selectors";
import GroupedBarChartComponent from "../components/graphics/GroupedBarChartComponent";
import Card from "@material-ui/core/Card";
import ToggleButtonContainer from "../components/ToggleButtonContainer";
import Toolbar from "@material-ui/core/Toolbar";
import {currentOptionInventoryDashboardSelector} from "../selectors";
import {setCurrentOptionInventoryDashboard} from "../actions";
import numeral from 'numeral';
import {theme} from '../ui';
import {getTwoColors} from '../utility'

export default function InventoryDashboard({classes}) {

    const dataLabels = [
        "Service Level",
        "Turns per Year",
        "Cycle Stock",
        "Safety Stock",
        "Inventory",
    ]

    const serviceLevel = useSelector(serviceLevelSelector);
    const turnsPerYear = useSelector(turnsPerYearSelector);
    const cycleStock = useSelector(cycleStockPerMonthSelector);
    const safetyStock = useSelector(safetyStockPerMonthSelector);
    const inventory = useSelector(averageInventoryPerMonthSelector);
    const overageInventory = useSelector(overageInventoryPerMonthSelector);
    const isReady = useSelector(inventoryRawDataSelector).size !== 0;

    const currentOptionInventoryDashboard = useSelector(currentOptionInventoryDashboardSelector);
    const currentDashboardData = useSelector(currentDashboardDataSelector);

    const dispatch = useDispatch();

    const handleCurrent = (event) => {
        dispatch(setCurrentOptionInventoryDashboard(event.currentTarget.value))
    };

    const displayOptions = {
        "Service Level": {
            format: v => `${v}%`,
            yAxis: 'Percentage'
        },
        "Turns per Year": {
            format: v => numeral(v).format('0.a'),
            yAxis: ''
        },
        "Cycle Stock": {
            format: v => `$${numeral(v).format('0.a')}`,
            yAxis: ''
        },
        "Safety Stock": {
            format: v => `$${numeral(v).format('0.0a')}`,
            yAxis: ''
        },
        "Inventory": {
            format: v => `$${numeral(v).format('0.0a')}`,
            yAxis: ''
        },
    }


    return (
        <Grid container spacing={3}>
            <Grid item xs={12} sm={2}>
                <CardContainer classes={classes} secondaryText={`${serviceLevel}%`} text={"Service Level"}
                               isReady={isReady}/>
            </Grid>
            <Grid item xs={12} sm={2}>
                <CardContainer classes={classes} secondaryText={turnsPerYear} text={"Turns/Year"} isReady={isReady}/>
            </Grid>
            <Grid item xs={12} sm={2}>
                <CardContainer classes={classes} secondaryText={`$${cycleStock}`} text={"Cycle Stock"}
                               isReady={isReady}/>
            </Grid>
            <Grid item xs={12} sm={2}>
                <CardContainer classes={classes} secondaryText={`$${safetyStock}`} text={"Safety Stock"}
                               isReady={isReady}/>
            </Grid>
            <Grid item xs={12} sm={2}>
                <CardContainer classes={classes} secondaryText={`$${inventory}`} text={"Inventory"} isReady={isReady}/>
            </Grid>
            <Grid item xs={12} sm={2}>
                <CardContainer classes={classes} secondaryText={`$${overageInventory}`} text={"Overage Inventory"}
                               isReady={isReady}/>
            </Grid>
            <Grid item xs={12}>
                <Card variant="outlined">
                    <Toolbar style={{paddingRight: 20, paddingTop: 20}}>
                        <Grid container justify={"flex-end"}>
                            <Grid item><ToggleButtonContainer current={currentOptionInventoryDashboard}
                                                              handleCurrent={handleCurrent}
                                                              data={dataLabels}/></Grid>
                        </Grid>
                    </Toolbar>
                    <GroupedBarChartComponent data={currentDashboardData} colors={getTwoColors(theme)}
                                              displayOptions={displayOptions[currentOptionInventoryDashboard]}/>
                </Card>
            </Grid>
        </Grid>
    );

}
