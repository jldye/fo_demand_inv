import React from 'react';
import {Paper, withStyles, Grid, TextField, Button, FormControlLabel, Checkbox} from '@material-ui/core';
import {Face, Fingerprint, SupervisedUserCircle} from '@material-ui/icons'
import Typography from "@material-ui/core/Typography";
import {
    useHistory,
    useLocation
} from "react-router-dom";

import {useDispatch} from "react-redux";
import {attemptLogin} from "../actions";


const styles = theme => ({
    margin: {
        margin: theme.spacing(2),
    },
    padding: {
        padding: theme.spacing(1),
        width: 400,
        margin: 100
    }
});

function LoginScreen({classes}) {
    const [user, setUser] = React.useState('user');
    const [client, setClient] = React.useState('cyient');
    const [password, setPassword] = React.useState('user#1');

    const history = useHistory();
    const location = useLocation();
    const {from} = location.state || {from: {pathname: "/"}};

    const dispatch = useDispatch();

    const onFieldChange = ({target}) => {

        if (target.id === 'user') {
            setUser(target.value);
        }

        if (target.id === 'client') {
            setClient(target.value);
        }

        if (target.id === 'password') {
            setPassword(target.value);
        }

    }

    return (
        <Grid container justify={"center"}>

            <Grid item>
                <Paper className={classes.padding}>
                    <form className={classes.margin}>
                        <Grid container spacing={8} alignItems="flex-end">
                            <Grid item>
                                <SupervisedUserCircle/>
                            </Grid>
                            <Grid item md={true} sm={true} xs={true}>
                                <TextField id="client" label="Client" type="text" fullWidth autoFocus required
                                           onChange={onFieldChange} value={client}/>
                            </Grid>
                        </Grid>
                        <Grid container spacing={8} alignItems="flex-end">
                            <Grid item>
                                <Face/>
                            </Grid>
                            <Grid item md={true} sm={true} xs={true}>
                                <TextField id="user" label="Username" type="text" fullWidth autoFocus required
                                           value={user} onChange={onFieldChange}/>
                            </Grid>
                        </Grid>
                        <Grid container spacing={8} alignItems="flex-end">
                            <Grid item>
                                <Fingerprint/>
                            </Grid>
                            <Grid item md={true} sm={true} xs={true}>
                                <TextField id="password" label="Password" type="password" fullWidth required
                                           value={password} onChange={onFieldChange}/>
                            </Grid>
                        </Grid>
                        <br/>
                        <br/>
                        <Grid container alignItems="center" justify="space-between">
                            <Grid item>
                                <FormControlLabel control={
                                    <Checkbox
                                        color="primary"
                                    />
                                } label="Remember me"/>
                            </Grid>
                            <Grid item>
                                <Button disableFocusRipple disableRipple style={{textTransform: "none"}} variant="text"
                                        color="primary"><Typography>Forgot Password?</Typography></Button>
                            </Grid>
                        </Grid>
                        <Grid container justify="center" style={{marginTop: '10px'}}>
                            <Button variant="outlined" color="primary" style={{textTransform: "none"}}
                                    onClick={() => dispatch(attemptLogin(client, user, password, history, from))}>Login</Button>
                        </Grid>

                    </form>
                </Paper>
            </Grid>
        </Grid>
    );
}


export default withStyles(styles)(LoginScreen);
