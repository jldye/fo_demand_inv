import React from "react";
import {useDispatch, useSelector} from "react-redux";
import {historyFileDetailsSelector} from "../selectors";
import TableWithExport from "../components/TableWithExport";
import _ from 'lodash';
import {
    getDemandRawData,
    getInventoryRawData,
    setCurrentDemandFile,
    setCurrentInventoryFile
} from "../actions";
import {useHistory} from "react-router-dom";
import Button from "@material-ui/core/Button";

const options = {
    filterType: 'checkbox',
    search: true,
    filter: false,
    print: false,
    selectableRowsHeader: false,
    selectableRowsHideCheckboxes: true,
    viewColumns: false,
    download: false
};


export default function HistoryDetails({classes}) {

    const tableColumns = [
        {"name": 'File Name', "label": "File Name"},
        {"name": 'Demand Forecasting', "label": "Demand Forecasting"},
        {"name": 'Inventory Analysis', "label": "Inventory Analysis"},
        {"name": 'Created Date', "label": "Created Date"},
        {
            "name": 'View', "label": "View", options: {
                customBodyRender: (value, {rowData}) =>
                    <Button disabled={_.isEmpty(rowData[1]) && _.isEmpty(rowData[2])}
                            color="primary"
                            onClick={() => handleClick(rowData)}>View</Button>
            }
        }
    ];

    const historyFileDetails = useSelector(historyFileDetailsSelector);

    const dispatch = useDispatch();
    const history = useHistory();

    const handleClick = (rowData) => {
        const inventoryFile = rowData[2];
        const demandFile = rowData[1];
        const inputFileName = _.find(historyFileDetails, function (o) {
            return o['File Name'] === rowData[0] && o['Created Date'] === rowData[3];
        })['Input File Name'];

        console.log(inputFileName);

        if (inventoryFile) {
            dispatch(setCurrentInventoryFile(inputFileName));
            dispatch(getInventoryRawData(inputFileName));
        }

        if (demandFile) {
            dispatch(setCurrentDemandFile(inputFileName));
            dispatch(getDemandRawData(inputFileName, 'Predictions - 24 Months'));
            dispatch(getDemandRawData(inputFileName, 'Forecast Vs Actual - 12 Months'));
            dispatch(getDemandRawData(inputFileName, '(5) Model Summary'));
            dispatch(getDemandRawData(inputFileName, 'History Raw Data'));
            dispatch(getDemandRawData(inputFileName, '(6) Historical Exception Report'));
            dispatch(getDemandRawData(inputFileName, '(7) Forecastable- Unmeasureable'));
            dispatch(getDemandRawData(inputFileName, '(8) Un-Forecastable Listing'));
        }

        if (inventoryFile) {
            history.push('/');
        } else {
            history.push('/demand');
        }


    }

    return (
        <main className={classes.content}>
            <div className={classes.toolbar}/>
            <TableWithExport columns={tableColumns}
                             data={historyFileDetails}
                             title={'File Details History'}
                             options={options}/>
        </main>
    )
}
