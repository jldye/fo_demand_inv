import React from "react";
import RadioButtonRow from "../components/RadioButtonRow";
import Toolbar from "@material-ui/core/Toolbar";
import Grid from "@material-ui/core/Grid";
import ToggleButtonContainer from "../components/ToggleButtonContainer";
import TableWithExport from "../components/TableWithExport";
import {useDispatch, useSelector} from "react-redux";
import {
    inventoryExceptionReportSelector,
    groupByPartSelector,
    groupByZoneSelector,
    inventoryDataRadioOptionSelector,
    inventoryDataToggleOptionSelector
} from "../selectors";
import {
    setInventoryDataRadioOption,
    setInventoryDataToggleOption
} from "../actions";
import numeral from 'numeral';

const toggleButtonData = [
    "Zone",
    "Part"
]

const radioButtonData = [
    {name: "Inventory Analysis", title: "Inventory Analysis"},
    {name: "Exception Report", title: "Exception Report"}
]


const options = {
    customBodyRender: (value) => (
        numeral(value).format('0.00')
    )
}

const percentOptions = {
    customBodyRender: (value) => (
        `${numeral(value*100).format('0.00')}%`
    )
}

const columns = {
    "Inventory Analysis": {
        "Zone": [
            {name: "Zone", label: "Zone"},
            {name: "Service Level", label: "Service Level", options: options},
            {name: "Turns per Year", label: "Turns/Year", options: options},
            {name: "Cycle Stock", label: "Cycle Stock/Month ($)", options: options},
            {name: "Safety Stock", label: "Safety Stock/Month ($)", options: options},
            {name: "Overage Inventory", label: "Overage Inventory/Month ($)", options: options},
            {name: "Average Inventory", label: "Average Inventory/Month ($)", options: options},
            {name: "On Hand Inventory", label: "On Hand Inventory ($)", options: options},
            {name: "Target Service Level", label: "Target Service Level", options: options},
            {name: "Target Turns per Year", label: "Target Turns/Year", options: options},
            {name: "Target Cycle Stock", label: "Target Cycle Stock/Month ($)", options: options},
            {name: "Target Safety Stock", label: "Target Safety Stock/Month ($)", options: options},
            {name: "Target Inventory", label: "Target Inventory/Month ($)", options: options}

        ],
        "Part": [
            {name: "Smart Part", label: 'Part Number'},
            {name: "Service Level", label: "Service Level", options: options},
            {name: "Turns per Year", label: "Turns/Year", options: options},
            {name: "Cycle Stock", label: "Cycle Stock/Month ($)", options: options},
            {name: "Safety Stock", label: "Safety Stock/Month ($)", options: options},
            {name: "Overage Inventory", label: "Overage Inventory/Month ($)", options: options},
            {name: "Inventory", label: "Average Inventory/Month ($)", options: options},
            {name: "On Hand Inventory", label: "On Hand Inventory ($)", options: options},
            {name: "Target Service Level", label: "Target Service Level", options: options},
            {name: "Target Turns per Year", label: "Target Turns/Year", options: options},
            {name: "Target Cycle Stock", label: "Target Cycle Stock/Month ($)", options: options},
            {name: "Target Safety Stock", label: "Target Safety Stock/Month ($)", options: options},
            {name: "Target Inventory", label: "Target Inventory/Month ($)", options: options}


        ]
    },
    "Exception Report": [
        {name: "Zone", label: "Zone"},
        {name: "Smart Part", label: "Smart Part Number"},
        {name: "Average COGs (Monthly)", label: "Average COGS (Monthly) ($)", options: options},
        {name: "Actual Safety Stock", label: "Actual Safety Stock ($)", options: options},
        {name: "Target Safety Stock", label: "Target Safety Stock ($)", options: options},
        {name: "Actual to Target", label: "Actual to Target", options: percentOptions},

    ]
}


export default function InventoryData() {

    const dispatch = useDispatch();
    const radioOption = useSelector(inventoryDataRadioOptionSelector);
    const toggleOption = useSelector(inventoryDataToggleOptionSelector);

    const dataOptions = {
        "Zone": useSelector(groupByZoneSelector),
        "Part": useSelector(groupByPartSelector),
        "Exception Report": useSelector(inventoryExceptionReportSelector)
    }


    const handleRadioChange = (event) => {
        dispatch(setInventoryDataRadioOption(event.target.value));
    };

    const handleToggleChange = (event) => {
        dispatch(setInventoryDataToggleOption(event.currentTarget.value))
    };

    return (
        <Grid container>
            <Grid item xs={12}>
                <Toolbar>
                    <Grid container justify={"center"}>
                        <Grid item>
                            <RadioButtonRow data={radioButtonData}
                                            value={radioOption}
                                            handleChange={handleRadioChange}/>
                        </Grid>
                    </Grid>

                </Toolbar>

                {radioOption === 'Inventory Analysis' && <Toolbar style={{paddingRight: 0, paddingBottom: 20}}>
                    <Grid container justify={"flex-end"}>
                        <Grid item>
                            <ToggleButtonContainer
                                data={toggleButtonData}
                                handleCurrent={handleToggleChange}
                                current={toggleOption}/>
                        </Grid>
                    </Grid>
                </Toolbar>}
            </Grid>
            <Grid item xs={12}>
                    <TableWithExport columns={radioOption === 'Exception Report' ?
                        columns[radioOption] : columns[radioOption][toggleOption]}
                                     data={radioOption === 'Inventory Analysis' ?
                                         dataOptions[toggleOption] : dataOptions[radioOption]}
                                     title={radioOption}
                                     options={{
                                         onRowSelectionChange: (a, b, c) => console.log(c)
                                     }}
                    />
            </Grid>
        </Grid>
    );
}
