import React from 'react';
import Grid from "@material-ui/core/Grid";
import CardContent from "@material-ui/core/CardContent";
import ToggleButtonContainer from "../components/ToggleButtonContainer";
import Card from "@material-ui/core/Card";
import Toolbar from "@material-ui/core/Toolbar";
import GroupedBarChartComponent from "../components/graphics/GroupedBarChartComponent";
import Typography from "@material-ui/core/Typography";
import TableWithExport from "../components/TableWithExport";
import TimeSeriesLineComponent from "../components/graphics/TimeSeriesLineComponent";
import {useDispatch, useSelector} from "react-redux";
import {
    currentOptionDemandDashboardSelector,
    demandBarChartSelector,
    demandForecastAccuracySelector,
    groupByPartAndCustomerFASelector,
    demandTimelineSelector
} from "../selectors";
import {setCurrentOptionDemandDashboard} from "../actions";
import {theme} from '../ui';
import {getColorGradient, getTwoColors} from '../utility'
import CircularProgress from "@material-ui/core/CircularProgress";
import numeral from 'numeral';

const toggleList = [
    "Full Period",
    "6 Months",
    "3 Months",
]

const displayOptions =
    {
        format: v => v,
        yAxis: 'Gross Margin',
        tooltip: ({id, value, index, indexValue, color, data}) => <span>{id}: <b>{value}</b></span>
    }

export default function DemandDashboard({classes}) {

    const dispatch = useDispatch();
    const currentOptionDemandDashboard = useSelector(currentOptionDemandDashboardSelector);
    const demandBarChart = useSelector(demandBarChartSelector);
    const barChartKeys = ["< 50%", "50% - 75%", "75% - 90%", "90% - 95%", "> 95%", "Un-Forecastable", "Un-Measureable"]
    const accuracy = useSelector(demandForecastAccuracySelector);
    const groupByPartAndCustomerFA = useSelector(groupByPartAndCustomerFASelector);
    const demandTimeline = useSelector(demandTimelineSelector);

    const stringOptions =  {
        customBodyRender: (value) => `${numeral(value).format('0,0.00')}`,
            sortCompare: (order) => {
            return (obj1, obj2) => {
                let val1 = parseInt(obj1.data, 10);
                let val2 = parseInt(obj2.data, 10);
                return (val1 - val2) * (order === 'asc' ? 1 : -1);
            };
        }
    }

    const numberOptions =  {
        customBodyRender: (value) => `${numeral(value).format('0,0.00')}`,
    }

    const percentOptions =  {
        customBodyRender: (value) => `${numeral(value).format('0,0.00')}%`,
    }

    const tableColumns = [
        {"name": 'Part', "label": "Part"},
        {"name": 'Customer', "label": "Customer"},
        {"name": 'Gross_Margin_Full_Period', "label": "Gross Margin ($)", options: numberOptions},
        {"name": 'fa_full_period', "label": "Forecast Accuracy", options: percentOptions}
    ];


    const handleCurrent = (event) => {
        dispatch(setCurrentOptionDemandDashboard(event.currentTarget.value))
    };


    return (
        <React.Fragment>
            <Toolbar style={{paddingRight: 0, paddingBottom: 20}}>
                <Grid container justify={"space-between"}>
                    <Grid item>
                        <Typography variant={"h6"}> Overall Model
                            Accuracy: {accuracy}%
                        </Typography>
                    </Grid>
                    <Grid item>
                        <ToggleButtonContainer data={toggleList} handleCurrent={handleCurrent}
                                               current={currentOptionDemandDashboard}/>
                    </Grid>
                </Grid>
            </Toolbar>
            <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                    <Card>
                        <CardContent>
                            {demandTimeline['timelineData'] ? <TimeSeriesLineComponent
                                data={demandTimeline['timelineData']}
                                colors={getTwoColors(theme)}/> : <CircularProgress/>}
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={12} sm={6}>
                    <Card>
                        <CardContent>
                            <GroupedBarChartComponent
                                groupMode={"grouped"}
                                keys={barChartKeys}
                                data={[demandBarChart]}
                                xAxis={''}
                                indexBy={''}
                                anchor={'bottom-right'}
                                translateX={120} translateY={-20}
                                displayOptions={displayOptions}
                                colors={getColorGradient(theme)}
                            />
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={12} sm={12}>
                    <TableWithExport columns={tableColumns} data={groupByPartAndCustomerFA}
                                     title={'Forecast (Full Period)'}/>
                </Grid>

            </Grid>
        </React.Fragment>
    );

}
